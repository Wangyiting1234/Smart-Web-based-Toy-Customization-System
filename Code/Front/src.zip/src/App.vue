<template>
  <div class="all">
    
    <Navbar></Navbar>
    <MainBar></MainBar>
    <router-view></router-view>
   
    <Footer></Footer>
  
  </div>
</template>

<script>
import MainBar from "@/components/MainBar";
import Footer from "./components/Footer";
import Navbar from "./components/Navbar";
export default {
  components: {
    Footer,
    Navbar,
    MainBar
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>



