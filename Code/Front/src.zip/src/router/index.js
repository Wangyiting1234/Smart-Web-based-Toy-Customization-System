
import VueRouter, { createRouter, createWebHashHistory } from 'vue-router'
import showToast from 'vant'
import HomeView from '../views/Home.vue'
import CustomizeView from '../views/CustomizeView.vue'
import Help from '../views/Help.vue'
import Signin from '../views/Signin'
import Log from '../views/Log'
import Hottoy from '../views/Hottoy'
import Account from '../views/Account'
import MyCart from '../views/MyCart'
import SearchList from "../views/SearchList"
import ProductIntro from "../views/ProductIntro"
import JoinUs from "../views/JoinUs"
import CollaborateUs from "../views/CollaborateUs"
import CustomerService from "../views/CustomerService"
import OrderStatus from "../views/OrderStatus"
import DeliverWay from "../views/DeliverWay"
import ExRecruitment from '../views/ExRecruitment'
import CamRecruitment from '../views/CamRecruitment'
import CustomizeGuide  from '../views/CustomizeGuide'
import MyCartEmpty from '../views/MyCartEmpty'
import Address from '../views/Address'
import ModifyPwd from '../views/ModifyPwd'
import MyCollection from '../views/MyCollection'
import LogOff from '../views/LogOff'
import DeliveryAddress from '@/views/DeliveryAddress'
import UnrecievedOrder from '@/views/UnrecievedOrder'
import ModifyUserInfo from '@/views/ModifyUserInfo'
import AddAddress from '@/views/AddAddress'
import EditAddress from '@/views/EditAddress'
import MyAddressEmpty from '@/views/MyAddressEmpty'
import ProductDetail from '@/views/ProductDetail'
import Toy from '@/views/Toy'
import Order from '@/views/Order'
import CustomizeConfirm from '@/views/CustomizeConfirm'
const routes=[
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/customize',
    name: 'customize',
    component: CustomizeView
  },
  {
    path: '/signin',
    name: 'signin',
    component: Signin
  },
  {
    path: '/log',
    name: 'log',
    component: Log
  },
  
  {
    path: '/help',
    name: 'help',
    component: Help
  },

  {
    path: '/searchlist',
    name: 'searchilist',
    component: SearchList,
  },
  {
    path: '/productintro',
    name: 'productintro',
    component: ProductIntro,
  },
  {
    path: '/joinus',
    name: 'joinus',
    component: JoinUs,
  },
  {
    path: '/collaborateus',
    name: 'collaborateus',
    component: CollaborateUs,
  },
  {
    path: '/customerservice',
    name: 'customerservice',
    component: CustomerService,
  },
  {
    path: '/orderstatus',
    name: 'orderstatus',
    component: OrderStatus,
  },
  {
    path: '/deliverway',
    name: 'deliverway',
    component: DeliverWay,
  },
  {
    path: '/myaddressempty',
    name: 'myaddressempty',
    component: MyAddressEmpty,
  },
  {
    path: '/exrecruitment',
    name: 'exrecruitment',
    component: ExRecruitment,
  },
  {
    path: '/camrecruitment',
    name: 'camrecruitment',
    component: CamRecruitment,
  },
  {
    path: '/customizeguide',
    name: 'customizeguide',
    component: CustomizeGuide,
  },
  {
    path: '/mycartempty',
    name: 'mycartempty',
    component: MyCartEmpty,
  },
  {
    path: '/hottoy',
    name: 'hottoy',
    component: Hottoy,
  },
  {
    path: '/productdetail/:id',
    name: 'productdetail',
    component: ProductDetail,
  },
  {
    path: '/order/:id',
    name: 'order',
    component: Order,
  },
  {
    path: '/customizeconfirm',
    name: 'customizefirm',
    component: CustomizeConfirm,
  },
 {
   path:'/toy',
   meta:{requireAuth:true, showFooter: true,index:0},
   component:Toy,
   childern:[
     

     
   ]
 },
 
  {
    path:'/address',
    meta:{requireAuth:true, showFooter: true,index:0},
    component:Address,
    children:[
      {
        path: 'addaddress',
        name: 'addaddress',
        component:AddAddress,
        meta:{
          showFooter: false,
          index:1
       }
       },
       {
        path: 'deliveryaddress',
        name: 'deliveryaddress',
        component: DeliveryAddress,
        meta:{
          showFooter:false,
          index:1,
       }
      },
      {
        path: 'editaddress',
        name: 'editaddress',
        component: EditAddress,
        meta:{
          showFooter:false,
          index:1,
       }
      },
    ]
  },
  {
    path:'/user',
    // name:'user',
    meta:{requireAuth:true, showFooter: true,index:0},
    component:Account,
    children:[
      
      {
        path: 'logoff',
        name: 'logoff',
        component: LogOff,
        meta:{
          showFooter: false,
          index:1
       }
      },
      {
        path: 'mycollection',
        name: 'mycollection',
        component: MyCollection,
        meta:{
          showFooter:false,
          index:1,
       }
      },
      {
        path: 'modifyuserinfo',
        name: 'modifyuserinfo',
        component: ModifyUserInfo,
        meta:{
          showFooter:false,
          index:1,
       }
      },
      {
        path: 'modifypwd',
        name: 'modifypwd',
        component: ModifyPwd,
        meta:{
          showFooter:false,
          index:1,
       }
      }, 
      {
        path: 'mycart',
        name: 'mycart',
        component: MyCart,
        meta:{
          showFooter:false,
          index:1,
       }
      },
      {
        path: 'unrecievedorder',
        name: 'unrecievedorder',
        component: UnrecievedOrder,
        meta:{
          showFooter:false,
          index:1,
       }
      },
    ]
  },
  {
		path: '/:catchAll(.*)',
		hidden: true,
		component: () => import('@/views/404.vue')//这个是我自己的路径
	},

  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  }
]
const router = createRouter({
 history: createWebHashHistory(process.env.BASE_URL),
 routes
})
router.beforeEach((to, from, next) => {
  if (to.meta.requireAuth) {  // 需要权限
      //判断当前是否拥有权限
      if (!sessionStorage.getItem("userId")) {
          // showToast("you have not log in");
          next({
            path:"/log",

          });
      } else {  // 无权，跳转登录
        next();
      }
  } else {  // 不需要权限，直接访问
      next();
  }
});
export default router



