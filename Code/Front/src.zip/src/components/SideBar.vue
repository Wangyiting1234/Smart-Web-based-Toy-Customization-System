<template>
  <div class="side">
    <ul>
      <div class="cate"  style="padding-top:16px">My Account</div>
      <li v-for="item in Account" :key="nav-item" @click="clickNav($event)">
        <div>
        <img class="nav-icon" :src="item.img"/>
          <router-link :to="item.url">{{ item.title }}</router-link>
        </div>
      </li>
    </ul>
    <ul>
      <div class="cate">Order Management</div>
      <li v-for="item in Order" :key="nav-item" @click="clickNav($event)">
        <div>
         <img class="nav-icon" :src="item.img"/>
          <router-link :to="item.url">{{ item.title }}</router-link>
        </div>
      </li>
    </ul>
  </div>
  
</template>

<script>
import { ref, reactive } from "vue";
export default {
  data() {
    return {
      Account: reactive([
        {
          title: "Modify password",
          url: "/user/modifypwd",
          img:require("../../img/pwd.png")
        },
        {
          title: "My collection",
          url: "/user/mycollection",
          img:require("../../img/collection.png")
        },
        {
          title: "log off",
          url: "/user/logoff",
          img:require("../../img/logoff.png")
        },
      ]),
      Order: reactive([
        {
          title: "Delivery address",
          url: "/address/deliveryaddress",
          img:require("../../img/address.png")
        },
        {
            title: "Order History",
            url:"/user/orderhistory",
            img:require("../../img/history.png")
        }
      ]),
    };
  },
  methods: {
    // clickNav(e) {
    //   // var domList = e.currentTarget.parentNode.children;
    //   // for (let d = 0; d < domList.length; d++) {
    //   //   domList[d].className = "nav-item";
    //   // }
    //   console.log("点击", e.currentTarget);
    //   e.currentTarget.className = "nav-item isclick";
    // },
  },
};
</script>

<style scoped>
li {
  list-style-type: none;
}

a {
  text-decoration: none;
  color: #39475a;
}
a:hover {
  color: #f1f1f1;
}

.side {
  height: 220px;
  background: #b0c4de;
  font-family: "nor";
}
.cate {
  font-size: 23px;
  font-weight: bold;
}

.nav-item {
  display:flex;
  width: 200px;
  height: 46px;
  color: #39475a;
  letter-spacing: 0;
  line-height: 46px;
  font-size:20px;
}
.nav-icon{
    width:17px;
    margin-right:5px
}

.nav-item div {
  margin-left: 17px;
  height: 46px;
  line-height: 46px;
}
</style>
