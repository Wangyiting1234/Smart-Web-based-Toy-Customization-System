<template>
  <div class="navrbar-fixed-bottom">
    <div class="container text-style">
      <div class="row">
        <div class=bottom-bar-height></div>
        <div class="col-4">
          <h4 style="font-weight:bold">
            <img src="../../img/fly.png" style="width:50px;height:50px;display:inlin-block"/>
            FLY TOY
          </h4>
          <div class="dis">
            Provide variable plush toys by the FLY TOY <br> and basic model of bears for you to design
            <br>
            Currently v1.1.1
          </div>
        </div>
        <div class="col-8">
          <div class="row">
            <div class="col">
              <h4 style="font-weight:bold">About Us</h4>
              <div><router-link class="nav-link" to="/productintro">Product Introduction</router-link></div>
              <div><router-link class="nav-link" to="/joinus">Join Us</router-link></div>
              <div><router-link class="nav-link" to="/collaborateus">Collaborate Us</router-link></div>
              
            </div>
            <div class="col">
              <h4 style="font-weight:bold">Here to help</h4>
              <router-link class="nav-link" to="/customerservice">Customer Service</router-link>
              <router-link class="nav-link" to="/orderstatus">Order Status</router-link>
              <router-link class="nav-link" to="/deliverway">Delivery Way</router-link>
            </div>
            <div class="col">
            </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.navrbar-fixed-bottom{
 height: 300px;
 width:100%;
 background-color:#b0c4de ;
 font-family:'nor';

}
.container{
  margin-top:0px;
}
.text-style{
  text-align: left;
}
.bottom-bar-height{
  height: 35px;
}
.nav-link:hover{
  color:#fff;
}
</style>