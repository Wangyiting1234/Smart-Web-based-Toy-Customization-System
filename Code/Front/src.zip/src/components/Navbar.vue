<template>
  <!--top navbar-->
  <div>
    <div class="header">
      <div class="box">
        <nav>
          <router-link style="margin: 20px" class="nav-link" to="/"
            >Home
          </router-link>
          <router-link style="margin: 20px" class="nav-link" to="/help"
            >Help?</router-link
          >
        </nav>
      </div>
      <div class="box">
        <nav>
          <router-link
            style="margin: 20px"
            type="flex"
            class="nav-link"
            to="/signin"
            >Sign Up</router-link
          >
          <router-link
            style="margin: 20px"
            type="flex"
            class="nav-link"
            to="/user"
            >My Account</router-link
          >
        </nav>
      </div>
    </div>
  </div>
  <!--end of top navbar-->
</template>
<style scoped>
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 45px;
  background-color: #b0c4de;
  color: #ffffff;

  /*吸顶效果*/
  position: sticky;
  position: -webkit-sticky;
  top: 0px;
}
.box {
  display: flex;
  align-items: center;
}
nav {
  display: flex;
  align-items: center;
  margin: 60px;
  font: 16px Arial;
  padding: 30px;
}
</style>

<script>
import router from "@/router";
export default {
  name: "Navbar",
};
</script>