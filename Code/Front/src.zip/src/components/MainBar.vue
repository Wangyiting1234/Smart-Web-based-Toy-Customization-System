<template>
  <div class="main">
    <img
      src="../../img/fly.png"
      style="width: 80px; height: 80px; margin: 10px"
    />
    <h4
      style="
        margin-top: 37px;
        width: 150px;
        font-weight: bold;
        font-size: 200%;
        font-family: 'title';
      "
    >
      FLY TOY
    </h4>
    <div class="container">
      <div class="row">
        <!--main requrements of customer-->
        <div
          class="col-6"
          style="font-weight: bold; font-size: 150%; font-family: 'nor'"
        >
          <div class="row">
            <div style="margin-top:5px" class="col-sm">
              <router-link class="nav-link" to="/hottoy">HOT TOYS</router-link>
            </div>
            <div class="col-sm">
              <van-config-provider :theme-vars="themeVars">
                <van-dropdown-menu class="cateDrop" active-color="#f1f1f1">
                  <van-dropdown-item
                    :title="classTitle"
                    :value="value_class"
                    :options="option1"
                  />
                </van-dropdown-menu>
              </van-config-provider>
            </div>
            <div style="margin-top:5px" class="col-sm">
              <router-link class="nav-link" to="/customize"
                >CUSTOMIZE</router-link
              >
            </div>
          </div>
        </div>
        <!--end of main requirements-->
        <!--search bar-->
        <div class="col-3">
          <div class="search">
            <form action="" onsubmit="return false" @keyup.enter="goSearchList">
              <input
                v-model="searchVal"
                type="search"
                class="searchTerm"
                style="font-family: 'nor'; font-weight: bold"
                placeholder="Search toys"
              />
            </form>
            <button type="search" class="searchButton" @click="goSearchList">
              <i class="fa fa-search"
                ><svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  class="bi bi-search"
                  viewBox="0 0 16 16"
                >
                  <path
                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"
                  />
                </svg>
              </i>
            </button>
          </div>
        </div>
        <!--end of search bar-->
        <!--collection& wish cart-->
        <div class="col-2">
          <div class="func">
            <div class="row">
              <div class="col-6">
                <router-link
                  class="nav-link"
                  type="flex"
                  to="/user/mycollection"
                >
                  <!--<path d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z"/></svg>-->
                  <img
                    src="../../img/collection.png"
                    style="width: 35px; height: 35px"
                  />
                </router-link>
              </div>
              <div class="col-6">
                <router-link class="nav-link" to="/user/MyCart">
                  <img
                    src="../../img/cart.png"
                    style="width: 35px; height: 35px"
                  />
                </router-link>
              </div>
            </div>
          </div>
        </div>
        <!--end of collection&wish cart-->
      </div>
    </div>
  </div>
</template>
<style >
.main {
  background-color: #739fd8;
  margin: 0 auto;
  height: 100px;
  display: flex;
  overflow: hidden;
  text-align: center;
}
.container {
  margin-top: 30px;
}
.func {
  margin-right: auto;
  position: relative;
  display: flex;
  float: right;
}

.search {
  margin-left: auto;
  position: relative;
  display: flex;
}
.cateDrop > .van-dropdown-menu__bar {
  background-color: #739fd8;
  box-shadow: none;
  font-weight: bold;
  /* font-size: 20px;  */
  font-family: "nor";
}


.searchTerm {
  border: 3px solid #b0c4de;
  border-right: none;
  padding: 15px;
  height: 20px;
  border-radius: 5px 0 0 5px;
  outline: none;
}

.searchTerm:focus {
  color: #000000;
}

.searchButton {
  width: 40px;
  height: 36px;
  border: 1px solid #b0c4de;
  background: #b0c4de;
  text-align: center;
  color: #fff;
  border-radius: 0 5px 5px 0;
  cursor: pointer;
  font-size: 20px;
}
.nav-link:hover {
  color: #f1f1f1;
}
</style>

<script>
import { ref, reactive, push } from "vue";
import { showToast } from "vant";
import axios from "axios";
import { baseURL } from "../../public/urlConfig";
export default {
  data() {
    return {
      searchVal: "",
      value1: ref(0),
      themeVars: reactive({
        DropdownMenuTitleFontSize: "25px",
      }),
      cate: [],
      value_class: 0,
      classTitle: "CATEGORIES",
      option1: [{ text: "All", value: 0 }],
    };
  },
  components: {},
  created() {
    this.getCateName();
  },

  methods: {
    getCateName() {
      var url = baseURL + "cate/getcatename";
      var self = this;
      axios.get(url).then((res) => {
        self.cate = res.data;
        if (res.data.state === 200) {
          const option1 = this.option1;

          for (let i = 1; i < self.cate.data.length; i++) {
            option1.push({});
            option1[i].text = self.cate.data[i - 1].cateName;
            option1[i].value = i;
          }
          this.option1 = option1;
        }
      });
    },
    goSearchList() {
      if (!this.searchVal) return;
      console.log(this.searchVal);
      //jump to wanted toys
      this.$router.push({
        path: "SearchList",
        query: {
          key: this.searchVal,
        },
      });
    },
  },
};
</script>
