import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";
import { FBXLoader } from "three/examples/jsm/loaders/FBXLoader";
class ModelView {

  constructor() {
    this.container = document.querySelector("#container");
    const width = container.clientWidth;
    const height = container.parentElement.clientHeight;
    this.k = width / height;
    this.s = 160;

    // 1. 创建场景
    this.scene = new THREE.Scene();

    // 2. 创建模型
    const group = new THREE.Mesh(
      new THREE.PlaneBufferGeometry(110, 110, 100),
      new THREE.MeshStandardMaterial({ color: 0xB0C4DE})
    );
    group.rotation.set(-Math.PI / 2, 0, 0);
    group.position.set(0, 0, 0);
    group.receiveShadow = true; //接收阴影
    group.castShadow = true; //造成阴影
    this.scene.add(group);

    // 2.2 点光源
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0xffffff, 2));
    var light = new THREE.SpotLight(0xffffff, 1);
    light.position.set(0, 2, 0);
    light.castShadow = true;
    light.shadow.mapSize.width = 1024 * 4; //影子边缘清晰度
    light.shadow.mapSize.height = 1024 * 4;
    this.scene.add(light);

    const hemiLight = new THREE.HemisphereLight(0xffffff, 0xffffff);
    hemiLight.position.set(0, 1, -2);
    this.scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight(0xffffff);
    dirLight.position.set(0, 1, -2);
    dirLight.castShadow = true;
    dirLight.shadow.camera.top = 80;
    dirLight.shadow.camera.bottom = - 50;
    dirLight.shadow.camera.left = - 50;
    dirLight.shadow.camera.right = 50;
    this.scene.add(dirLight);

    var ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    this.scene.add(ambientLight);

    // 3. 创建摄像机
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(0, 2, -6.5);
    this.camera.lookAt(0, 1, 0);

    // 4. 创建渲染器
    this.renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
    });
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true; //开启阴影渲染
    this.renderer.setClearColor(0xCCDDFF, 1);
    this.container.appendChild(this.renderer.domElement);
    this.model = null;
    this.Glasses = null;
    this.Cap = null;
    this.Hood = null;
    this.hair=null;

    this.InitModel();
    // this.initControl();

    // 5. 执行渲染
    this.animate();
  }
  InitModel() {
    var loader = new FBXLoader();
    loader.load("./mesh/bear.fbx", (object) => {
      object.getObjectByName("Box002").material.map = new THREE.TextureLoader().load(
        "./mesh/AM96_025_color_01.jpg"
      );
      object.getObjectByName("Sphere001").material.map = new THREE.TextureLoader().load(
        "./mesh/AM96_025_color_01.jpg"
      );
      object.getObjectByName("Sphere002").material.map = new THREE.TextureLoader().load(
        "./mesh/AM96_025_color_01.jpg"
      );
      object.getObjectByName("Sphere003").material.map = new THREE.TextureLoader().load(
        "./mesh/AM96_025_color_01.jpg"
      );
      object.getObjectByName("Sphere004").material.map = new THREE.TextureLoader().load(
        "./mesh/AM96_025_color_01.jpg"
      );
      object.position.set(0, 1, -3);
      object.scale.set(0.7,0.7,0.7);
      object.rotation.y = Math.PI;
      this.model = object;
      this.scene.add(object);
      this.model.traverse(function (child) {
        if (child.name.includes("Cap") || child.name.includes("Glasses") || child.name.includes("Hair") || child.name.includes("HairHoop") || child.name.includes("Helmet") || child.name.includes("Hat") || child.name.includes("Hood") || child.name.includes("HariHoop")) {
          child.visible = false;
        }
        else {
          console.log(child.name);
        }
      })
    });

  }

  initControl() {
    // 6. 添加控件
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    //限制相机滚轮缩放距离
    this.controls.minDistance = 0;
    this.controls.maxDistance = 250;
    //限制相机角度
    this.controls.minPolarAngle = 0;
    // orbit.maxPolarAngle=Math.PI/2;
    //阻力 松开鼠标有滑动
    this.controls.enableDamp = true;
    //自动旋转
    this.controls.autoRotate = false;
  }

  animate() {
    this.renderer.setAnimationLoop(this.tick.bind(this));
  }
  tick() {

    this.renderer.render(this.scene, this.camera);
    // this.controls.update();
  }

  SetModelShow(name) {
    var obj = this.model.getObjectByName(name);
    obj.visible = true;
    if (name.includes("Glasses")) {
      if (this.Glasses != null) {
        this.Glasses.visible = false;
        if (this.Glasses.name == name) {
          this.Glasses = null;
          return;
        }
      }
      this.Glasses = obj;
    }
    else if (name.includes("Cap")||name.includes("Hat")) {
      if (this.Cap != null) {
        this.Cap.visible = false;
        if (this.Cap.name == name) {
          this.Cap = null;
          return;
        }
      }
      this.Cap = obj;
    }
    else if (name.includes("Hair")) {
      if (this.Hair != null) {
        this.Hair.visible = false;
        if (this.Hair.name == name) {
          this.Hair = null;
          return;
        }
      }
      this.Hair = obj;
    }
    else if (name.includes("Hood")) {
      if (this.Hood != null) {
        this.Hood.visible = false;
        if (this.Hood.name == name) {
          this.Hood = null;
          return;
        }
      }
      this.Hood = obj;
    }
  }
}
export default ModelView;