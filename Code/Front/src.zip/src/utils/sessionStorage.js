const setItem=(key,value)=>{
    return window.sessionStorage.setItem(key,value)
}
const getItem=(key)=>{
    return window.sessionStorage.getItem(key)
}
const removeItem=(key)=>{
   window.sessionStorage.removeItem(key)
}
export default (setItem,getItem,removeItem)