import axios from "axios"
import router from '@/router/index'
import { showToast } from 'vant'
const request = axios.create({
    baseURL: 'api',
    timeout: 60000
})
// request.interceptors.request.use(config => {
//     if (window.sessionStorage.getItem("token")) {
//         config.headers['Ahthorization'] = window.sessionStorage.getItem("token");
//     }
//     return config;
// }, error => {
//     ShowToast(error);
// });

// response 拦截器
// 可以在接口响应后统一处理结果
request.interceptors.response.use(
    response => {
        let res = response.data;
        if (response.state != 200) {
            if (response.state === 5003) { 
                showToast(res.data.message);
                this.$router.push("/login")
            }
        }
        return res;
    },
    error => {
        console.log('err' + error) // for debug
        return Promise.reject(error)
    }
)


export default request

