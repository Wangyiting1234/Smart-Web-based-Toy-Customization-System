import Vue from 'vue'
import { createApp } from 'vue'
import axios from 'axios'
import App from './App.vue'
import router from './router'
import store from './store'
// import axios from 'axios'
import bootstrapcss from './bootstrap/css/bootstrap.min.css'
import bootstrapjs from './bootstrap/js/bootstrap.bundle'
import Vant from 'vant'
import 'vant/lib/index.css'
import './assets/font/font.css'
// import VueRouter from 'vue-router'
import request from "@/utils/axios"
import {Locale} from 'vant';
import enUS from 'vant/lib/locale/lang/en-US'

Locale.use('en-US',enUS);
axios.defaults.withCredentials=true;
createApp(App).use(store, bootstrapcss, bootstrapjs).use(Vant).use(router).mount('#app')

createApp(App).config.globalProperties.$axios = request;
