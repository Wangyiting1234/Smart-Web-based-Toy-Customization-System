<template>
  <div class="row">
    <h1 style="text-align: left; font-family: 'swe'; margin: 20px">
      Confirm Your Order
    </h1>
    <div class="col-2"></div>
    <div class="col-8 info">
      <div class="address">
        <div><p>Select Delivery Address:</p></div>
        <select>
          <option v-for="(item, index) in list" :key="index">
            {{ item.receiverName }} {{ item.address }} {{ item.receiverPhone }}
          </option>
        </select>
      </div>
    </div>
    <div class="col-2"></div>
  </div>
</template>

<style>
.col-8 .info {
  display: flex;
  font-weight: bolder;
  font-family: "nor";
}

.address {
  display: flex;
  flex-direction: column;
  float: left;
  width: 100%;
}
</style>
<script>
import { ref } from "vue";
import { showToast } from "vant";
import axios from "axios";
import { baseURL } from "../../public/urlConfig";
export default {
  data() {
    return {
      list: [],
      address: [],
      total: "",
      obj: {},
    };
  },
};
</script>