<template>
   <div class="row">
        <h1 style="text-align: left; font-family: 'swe'; margin: 20px">
      Confirm Your Order
    </h1>

    <div class="col-2"></div><div class="col-8"></div><div class="col-2"></div></div> 
</template>
<script></script>
<style></style>