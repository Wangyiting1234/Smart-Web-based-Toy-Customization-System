<template>
    <div class="row">
        <div style="height:35px"></div>
        <div clss="col-2"></div>
        <div clss="col-8">
            <h1 style="font-family:'swe';">DO YOU WANT TO DIY A PERFECT BEAR ?</h1>
            <h3 style="font-family:'nor'">Read the folllowing tips<br>May give you more inspiration</h3>
            <div style="height:35px"></div>
            <div class="tipVideo">
                <div class="Video">
                <video muted="muted" class="video" src="../../video/CustomizeGuide.mp4" type="video/mp4" autoplay="autoplay" controls="controls">
               </video>
                <div><h3 class="des">Watch the video on the side for tips on how not to get it wrong</h3>
               </div>
               </div>
           </div>
           <div style="height:45px"></div>
           <div class="sample">
               <div style="height:10px"></div>
              <span style="font-family:'nor';font-size:30px;font-weight:bold;display:flex;margin-left:20px">INTERESTING DESIGNS OF BEAR BY CLIENTS</span>
              <section>
                  <ul>
                      <li>
                          <img src= "../assets/sample/sample1.jpg">
                          <span class="sampleName">Design by Elsa</span>
                      </li>
                       <li>
                          <img src='../assets/sample/sample2.jpg'>
                           <span class="sampleName">Design by Elsa</span>
                      </li> <li>
                          <img src='../assets/sample/sample3.jpg'>
                           <span class="sampleName">Design by Elsa</span>
                      </li>
                       <li>
                          <img src='../assets/sample/sample4.jpg'>
                           <span class="sampleName">Design by Elsa</span>
                      </li>
                  </ul>
              </section>
            </div>
            <div style="height:35px"></div>
            <div>
                 <h1 style="font-family:'swe';">DO YOU READY TO DIY A PERFECT BEAR ?</h1>
            <h3 style="font-family:'nor'">LET US START NOW!</h3>
            <router-link  to="/customize"><button type="button" style="font-family:'nor'" class="btn btn-primary">CUSTOMIZE</button></router-link>
            <div style="height:35px"></div>
            </div>
        </div>
        <div clss="col-2"></div>
    </div>
</template>
<style scoped>
video{
    display: flex;
    width:70%;
}
.tipVideo{
    display: flex;
      background-color:#739fd8 ;
}
.Video{
    display: flex;

}
.des{
    font-weight:bold;
    margin-left:3%;
    font-family: 'nor';
    margin-top:50%;
    justify-content:center;  
}
.sample{
    height:400px;
    background-color:#739fd8;
    font-weight:bold;
}
.designTip{
    height:400px;
    background-color:#739fd8;
}
section {
  flex: 1;
  overflow: hidden;
  font-family: "nor";
}
section ul {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
}
section ul li {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
section ul li img{
    width:300px;
    height:300px;
    background-color: #fff;
}
.sampleName{
    margin:10px;
}
</style>