<template>
  <div class="row">
    <h1 style="font-family: 'swe'; margin: 20px">MY ADDRESS LIST</h1>
    <div class="col-2"></div>
    <div class="col-8">
      <div id="app">
        <table>
          <tr>
            <th>Default</th>
            <th>Number</th>
            <th>Name</th>
            <th>Telephone</th>
            <th>Full Address</th>
            <th>Actions</th>
          </tr>
          <tr v-for="(item, index) in list" :key="index">
            <td>
              <span v-if="item.isDefault == 0">
                <button
                  @click="setDefault(item.add_id)"
                  class="btn btn-primary"
                >
                  Set
                </button>
              </span>
            </td>
            <td>{{ item.id }}</td>
            <td>{{ item.receiverName }}</td>
            <td>{{ item.receiverPhone }}</td>
            <td style="width: 40%">{{ item.address }}</td>
            <td>
              <button
                class="btn btn-primary"
                style="width: 55px; height: 35px; margin: 5px"
                @click="onEdit(item, index)"
              >
                Edit
              </button>
              <button
                style="width: 55px; height: 35px; margin: 5px"
                class="btn btn-primary"
                @click="onDelete(item.add_id)"
              >
                Delete
              </button>
            </td>
          </tr>
        </table>
        <div class="addNew">
          <router-link to="/address/addaddress">
            <button class="btn btn-primary">
              Add new address
            </button></router-link
          >
        </div>
        <div style="height: 30px"></div>
              <van-popup
        v-model:show="showPopover"
        position="bottom"
        :style="{ height: '70%' }"
      >
        <van-address-edit
          :area-list="areaList"
          :address-info="AddressInfo"
          show-delete
          show-set-default
          show-area
          :search-result="searchResult"
          :area-columns-placeholder="['Choose', 'Choose', 'Choose']"
          @save="
            (content) => {
              onSave(1, content);
            }
          "
          @delete="onDelete(item.add_id)"
          @change-detail="onChangeDetail(AddressInfo)"
        />
      </van-popup>
      </div>

    </div>
    <div class="col-2"></div>
  </div>
</template>
<script>
import { ref } from "vue";
import { showToast } from "vant";
import axios from "axios";
import { baseURL } from "../../public/urlConfig";
export default {
  data() {
    return {
      areaList: {
        province_list: {
          110000: "Beijing",
          330000: "Zhejiang Province",
        },
        city_list: {
          110100: "Beijing City",
          330100: "Hangzhou",
        },
        county_list: {
          110101: "Dongcheng District",
          110102: "Xicheng District",
          // ....
        },
      },
      showPopover: ref(false),
      address: [],
      list: [],
      AddressInfo: [],
      checked: "",
    };
  },
  created() {
    if (!window.sessionStorage.getItem("userId")) {
      this.$router.push("/myaddressempty");
    }
    this.loadAddress();
  },
  methods: {
    onEdit(item, index) {
      this.showPopover = ref(true);
      this.AddressInfo = {
        name: item.receiverName,
        tel: item.receiverPhone,
        province: item.province,
        city: item.city,
        county: item.area,
        addressDetail: item.address,
      };
      return { showPopover };
    },
    onSave(id, content) {
      this.AddressInfo = {
        name: content.name,
        tel: content.tel,
        province: content.province,
        city: content.city,
        county: content.county,
        addressDetail: content.addressDetail,
      };
      // 搞定了
      // 第一个问题：字段用错了 
      //第二个问题  你之前那样的传参方式 会把事件的默认参数给干掉 应该用  @save="
          //   (content) => {
          //     onSave(1, content);
          //   }
          // "
          // 第三个问题 ： 没有 item.add_id  这个item和这个弹窗不在一个div下  拿不到item
      console.log(this.AddressInfo);
      console.log(id);
      console.log(content);
      content.isDefault = content.isDefault ? "1" : "0";
      var url =
        baseURL +
        "address/" +
        id +
        "/updateaddress" +
        "?" +
        "receiverName=" +
        content.name +
        "&receiverPhone=" +
        content.tel +
        "&province=" +
        content.province +
        "&city=" +
        content.city +
        "&area=" +
        content.county +
        "&address=" +
        content.addressDetail +
        "&isDefault=" +
        content.isDefault +
        "&postCode=" +
        content.areaCode;
      console.log(content.name);
      axios
        .get(url, {
          receiverName: content.name,
          receiverPhone: content.tel,
          province: content.province,
          city: content.city,
          area: content.county,
          address: content.addressDetail,
          isDefault: this.isDefault,
          postCode: content.areaCode,
        })
        .then((res) => {
          console.log("2");
          if (res.data.state === 200) {
            showToast("update address successfully");
            this.loadAddress();
            this.$router.push("/address/deliveryaddress");
          } else if (res.data.state === 4002) {
            showToast(res.data.message);
            this.$router.push("/log");
          } else if (res.data.state === 4003) {
            showToast(res.data.message);
          } else if (res.data.state === 5010) {
            showToast(res.data.message);
          }
        });
    },
    onDelete(id) {
      var url = baseURL + "address/" + id + "/deleteaddress";
      axios.get(url).then((res) => {
        if (res.data.state === 200) {
          this.loadAddress();
          this.$router.push("/address/deliveryaddress");
          this.loadAddress();
          showToast("delete successfully");
        } else if (res.data.state === 4002) {
          showToast(res.data.message);
          this.$router.push("/log");
        } else if (res.data.state === 4003) {
          showToast(res.data.message);
        } else if (res.data.state === 5009) {
          showToast(res.data.message);
        }
      });
    },
    setDefault(id) {
      var url = baseURL + "address/" + id + "/setdefault";
      axios.get(url).then((res) => {
        if (res.data.state === 200) {
          this.loadAddress();
          this.$router.push("/address/deliveryaddress");

          showToast("set successfully");
        } else if (res.data.state === 4002) {
          showToast(res.data.message);
          this.$router.push("/log");
        } else if (res.data.state === 4003) {
          showToast(res.data.message);
        } else if (res.data.state === 5008) {
          showToast(res.data.message);
        }
      });
    },
    loadAddress() {
      var url = baseURL + "address/deliveryaddress";
      var self = this;
      axios.get(url).then((res) => {
        self.address = res.data;

        if (res.data.state === 200) {
          this.list = self.address.data;

          if (self.address.data.length == 0) {
            this.$router.push("/myaddressempty");
          }
          for (let i = 0; i < self.address.data.length; i++) {
            this.list[i].id = i + 1;
          }
        }
      });
    },
  },
};
</script>
<style scoped>
table {
  width: 100%;
}
.active {
  color: #ff0000;
}
th {
  font-size: 20px;
}
td {
  font-family: "nor";
}
</style>