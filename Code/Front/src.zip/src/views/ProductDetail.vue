<template>
  <div style="height: 30px"></div>

  <!-- 产品详细信息区域 -->
  <div class="row">
    <div class="col-1"></div>
    <div class="col-5">
      <div class="imgShow"><img :src="require(`../assets/tony/${productParam.img}`)" alt="" /></div>
    </div>
    <div class="col-6">
      <section>
        <ul>
          <li style="margin-top: 30px; font-size: 35px">
            {{ productParam.productName }}
          </li>
          <li style="font-size: 30px; margin-top: 10px; margin-bottom: 30px">
            <span >￥<span v-if="size==0">{{product[0].price}}</span></span>
             <span v-if="size==1">{{product[1].price}}</span>
          </li>
          <hr />
          <li>
            <div class="a24">
              <span class="color" style="font-size: 20px">Color</span>
              <van-radio-group v-model="color" direction="horizontal">
                <span v-for="(item, index) in colorlist" :key="index" class="bang">
                  <van-radio :name="index">{{ item }}</van-radio>
                </span>
              </van-radio-group>
            </div>
          </li>
          <li>
            <div class="a24">
              <span class="size" style="font-size: 20px">Size</span>
              <van-radio-group v-model="size" direction="horizontal">
                <span v-for="(item, index) in sizelist" :key="index" class="bang">
                  <van-radio :name="index">{{ item }}</van-radio>
                </span>
              </van-radio-group>
            </div>
          </li>
          <li>
            <div class="a24">
              <span class="quantity" style="font-size: 20px; margin-right: 10px"
                >Quantity</span
              >
              <van-stepper v-model="value" />
            </div>
          </li>
          <li>
            <hr />
            <div class="a25">
              <button class="btn btn-primary" @click="gotoBuy(productId,value)">Buy Me</button>
              <button
                class="btn btn-primary"
                @click="addToCart(productId, value)"
              >
                Add to Cart
              </button>
            </div>
          </li>
        </ul>
      </section>
    </div>
  </div>
  <hr />
  <div class="row">
    <div class="col-2"></div>
    <div class="col-8">
      <div class="detail">
        <section>
          <p
            style="
              margin-top: 20px;
              font-size: 35px;
              font-family: 'nor';
              font-weight: bold;
            "
          >
            Product Detail
          </p>
          <ul>
            <!-- <li>Toy Name:{{ productParam.productName }}</li> -->

            <li>Toy Material:{{ product[0].material }}</li>
            <li>
             Toy Size:<table>
                <thead><tr><th>Size</th><th>Height</th><th>Weight</th></tr></thead>
                <tbody><tr><td>{{sizelist[0]}}</td><td>{{heightlist[0]}}</td><td>{{weightlist[0]}}</td></tr><tr><td>{{sizelist[1]}}</td><td>{{heightlist[1]}}</td><td>{{weightlist[1]}}</td></tr></tbody>
             </table>
            </li>
            <li>
              Delivery Way:FLY TOY Members get free standard shipping (and
              discounted expedited shipping) on every order. Otherwise, guestes
              are required to pay ￥30 for each order Just sign in during
              checkout and you’ll automatically get free shipping.
            </li>
            <li>Introduction:{{ productParam.dis }}</li>
            <li><div  v-for="(item, index) in imglist"
        :key="index" style="margin:5%;"><img 
            v-if="item.path"
            style="width: 100%;"
            :src="require(`../assets/donkey/${item.path}`)"
            class="rounded float-start"
            alt="..."
          /></div>
                  
     
            </li>
          </ul>
        </section>
      </div>
    </div>
    <div class="col-2"></div>
  </div>
</template>
<style scoped>
img {
  width: 95%;
  height: 95%;
  border: 2px solid rgb(187, 189, 190);
}
section ul {
  font-weight: bolder;

}
.detail ul {
  display: flex;
  flex-direction: column;
    font-family: "nor";
  background-color: rgb(231, 236, 238);
}

.detail ul li {
  /* margin-top: 10px; */
  font-size: 20px;
  text-align: left;
  margin: 15px;
}
.imgShow {
  width: 100%;
  height: 550px;
}
.a24 {
  margin-top: 40px;
  display: flex;
}
.a24 .bang{
 margin:7px;
}


.a25 {
  margin-top: 30px;
}
.a25 button {
  margin-top: 30px;
  display: inline-block;
  width: 200px;
  height: 60px;
  border-radius: 30px;
  margin-left: 30px;
}
table
        {
            border-collapse: collapse;
            /* margin: 0 auto; */
            text-align: center;
        }
        table td, table th
        {
            border: 1px solid #cad9ea;
            color: #666;
            height: 30px;
        }
        table thead th
        {
            background-color:  #b0c4de;
            width: 100px;
        }
        table tr:nth-child(odd)
        {
            background: #fff;
        }
        table tr:nth-child(even)
        {
            background: #fff;
        }

</style>
<script>
import axios from "axios";
import { baseURL } from "../../public/urlConfig";
import { showToast } from "vant";
export default {
  data() {
    return {
      img:[],
      imglist:[],
      product: [],
      list1: [],
      list2: [],
      productParam: [],
      value: "",
      productId: "",
      color: "",
      size:"",
      price:'',
      sizelist:[],
      colorlist:[],
      heightlist:[],
      weightlist:[],
    };
  },
  created() { 
    this.size=0;
    this.color=0;
    this.value=1;
    let productId = this.$route.params.id;
    var url1 = baseURL + "productdetail/" + productId;
    var url2 = baseURL + "toy/" + productId;
    var url3 = baseURL+ "toy/"+productId +"/img";

    var self = this;
             axios.get(url3).then((res) => {
       
        
          self.img = res.data;
        if (res.data.state === 200) {
             
              this.imglist = self.img.data;
              console.log(this.imglist)
        }
         })
    axios.get(url1).then((res) => {
      self.list1 = res.data;
      if (res.data.state === 200) {
        this.product = self.list1.data;
        console.log(this.list1.data);
        this.productId = this.$route.params.id;
        window.sessionStorage.setItem("productId", this.productId);

        console.log(this.product)
        for(let i=0;i<this.product.length;i++){
         if(this.sizelist.indexOf(this.product[i].size)=="-1"){ this.sizelist.push(this.product[i].size);}
          if(this.colorlist.indexOf(this.product[i].color)=="-1"){ this.colorlist.push(this.product[i].color);}
          if(this.heightlist.indexOf(this.product[i].height)=="-1"){ this.heightlist.push(this.product[i].height);}
          if(this.weightlist.indexOf(this.product[i].weight)=="-1"){ this.weightlist.push(this.product[i].weight);}
           console.log(this.heightlist);
            console.log(this.weightlist);
        }
       
      }
    });
   
    axios.get(url2).then((res) => {
      self.list2 = res.data;
      if (res.data.state === 200) {
        this.productParam = self.list2.data;
        console.log(this.list2);
      }
    });
    
  },
  methods: {
    gotoBuy(id, number){
           if(this.size===0){
         this.size = "small"
          this.price = this.product[0].price;
       }else{
         this.size = "medium"
         this.price = this.product[1].price;
       }
            if(this.color===0){
         this.color = this.product[0].color
       }else{
         this.color = this.product[1].color
       }
       this.$router.push({
          path:`/order/${id}`,
          query:{         
            size:this.size,
            color:this.color,
            productNum:number,  
            productName:this.productParam.productName,
            productPrice:this.price,

          }
      })
    },
    addToCart(id, number) {
       if(this.size===0){
         this.size = "small"
       }else{
         this.size = "medium"
       }
        if(this.color===0){
         this.color = this.product[0].color
       }else{
         this.color = this.product[1].color
       }
      var url =
        baseURL +
        "cart/addcart" +
        "?" +
        "productId=" +
        id +
        "&productNum=" +
        number+
        "&size=" +
        this.size+
        "&color=" +
        this.color
        ;
      axios.get(url).then((res) => {
        console.log(id);
        console.log(number);
        if (res.data.state === 200) {
          showToast("add to cart successfully");
        }else if (res.data.state === 5003) {
          showToast(res.data.message);
          this.$router.push("/log");
        }
      });
    },

  },
};
</script>
