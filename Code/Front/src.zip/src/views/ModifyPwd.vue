<template>
  <div style="height: 40px"></div>
  <h1 style="font-family: swe">Modify Password</h1>
  <div class="row" style="margin: 20px; font-family: nor; font-weight: bold">
    <div class="col-3"></div>
    <div class="col-6">
      <van-form @submit="onSubmit">
        <van-cell-group inset>
          <van-field
            v-model="userCurPwd"
            type="password"
            name="userCurPwd"
            label="Current password*"
            placeholder="please input your current password"
            :rules="pwdRules"
          />
          <van-field
            v-model="userNewPwd"
            type="password"
            name="userNewPwd"
            label="New password*"
            placeholder="please input your new password"
            :rules="pwdRules"
          />
          <van-field
            v-model="userConPwd"
            type="password"
            name="userConPwd"
            label="Confrim Password*"
            placeholder="please confirm your new password"
            :rules="ConPwdRules"
          />
        </van-cell-group>
        <div style="margin: 16px">
          <van-button round block type="primary" native-type="submit">
            Confirm
          </van-button>
        </div>
      </van-form>
    </div>
    <div class="col-3"></div>
  </div>
</template>
<script>
import { baseURL } from "../../public/urlConfig";
import { showToast } from "vant";
import axios from "axios";
export default {
  name: "modifyPwd",
  data() {
    return {
      userCurPwd: "", //user input
      userNewPwd: "",
      userConPwd: "",
      //rules of vertification
      pwdRules: [
        {
          required: true,
          message: "password can be not empty",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return /^\w{6,12}$/.test(value);
          },
          message: "please check the format of password",
          trigger: "onBlur",
        },
      ],
      ConPwdRules: [
        {
          required: true,
          message: "password can be not empty",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return /^\w{6,12}$/.test(value);
          },
          message: "please check the format of password",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return this.userNewPwd == value;
          },
          message: "confirm passwords are same",
          trigger: "onBlur",
        },
      ],
    };
  },
  // created(){
  //    if(!window.localStorage.getItem("userId")){
  //         this.$router.push({path:'/log'})
  //     }
  // },
  methods: {
    onSubmit(values) {
      var url = baseURL + "user/modifypwd"+"?" +
        "userCurPwd=" +
        this.userCurPwd +
        "&userNewPwd=" +
        this.userNewPwd;;
      axios
        .post(url, {
          userCurPwd: this.userCurPwd,
          userNewPwd: this.userNewPwd,
        })
        .then((res) => {
          if (res.data.state === 200) {
            showToast("Modify successfully");
            this.$router.push("/");
          } else if (res.data.state === 5004) {
            showToast(res.data.message);
          } else if (res.data.state === 5005) {
            showToast(res.data.message);
          } else if (res.data.state === 5002) {
            showToast(res.data.message);
          }
        });
    },
  },
};
</script>