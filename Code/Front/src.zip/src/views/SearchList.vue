<template>
  <div class="searchList">
    <h1 style="text-align: left; font-family: 'swe'; margin: 20px">
      Search for {{ this.$route.query.key }}
    </h1>

    <div class="row">
      <div class="header">
        <ul>
          <li><div>(number)items</div></li>
          <li :class="current == 'price' ? 'active' : ''" @click="doPrice">
            <div>Price</div>
            <div class="search-filter">
              <i><img class="icon arrorw_up" src="../../img/up.png" /></i>
              <i><img class="icon arrorw" src="../../img/down.png" /></i>
            </div>
          </li>
          <li :class="current == 'sales' ? 'active' : ''" @click="doSales">
            <div>Sales</div>
            <div class="search-filter">
              <i><img class="icon arrorw_up" src="../../img/up.png" /></i>
              <i><img class="icon arrorw" src="../../img/down.png" /></i>
            </div>
          </li>
        </ul>
      </div>
      <div style="height: 35px"></div>
      <div class="col-2"></div>
      <div class="col-8">
        <section>
          <ul>
            <li v-for="(item, index) in goodlist" :key="index">
              <!-- <img src="item.imgUrl" alt="" /> -->
              <!-- <h3>{{item.name}}</h3> -->
              <h5>
                <div class="price">
                  <!-- <span>￥<b>{{item.price}}</b></span> -->
                  <div>
                    <button class="btn btn-primary" type="submit">BUY</button>
                  </div>
                </div>
              </h5>
            </li>
          </ul>
        </section>
      </div>
      <div class="col-2"></div>
    </div>
  </div>
</template>
<style scoped>
.header ul {
  font-family: "nor";
  font-weight: bold;
  display: flex;
  align-items: center;
  justify-content: space-around;
  height: 50px;
  background-color: #b0c4de;
  color: #ffffff;
  top: 0px;
}
.icon {
  height: 20px;
  width: 20px;
}

.header ul li {
  display: flex;
  align-items: center;
}
.header ul li > div {
  padding: 0 5px;
  font-size: 20px;
}
.search-filter {
  display: flex;
  flex-direction: column;
}
.col-4:after {
  border: 1px soild slategray;
}
section {
  flex: 1;
  overflow: hidden;
  font-family: "nor";
}
section ul {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}
section ul li {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
section ul li img {
  width: 300px;
  height: 300px;
}
section ul li h5 {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  width: 200px;
}
section ul li .price {
  display: flex;
  justify-content: space-between;
  width: 100%;
  padding: 10px 0;
}
</style>
<script>
export default {
  data() {
    return {
      goodList: [],
      searchList: {
      },
    };
  },
  created(){
    this.list=data;
  },
  methods: {
    doSort(prop){
      return function (a,b){
        let val1 = a[prop];
        let val2 = b[prop];
        return val1-val2;
      }
    },
    doPrice(){
      this.list.sort(this.doSort("price"));
      this.current = "price";
    },
    doSales(){
      this.list.sort(this.doSort("sales"));
      this.current = "sales";
    }
  },
  created() {},
};
</script>
