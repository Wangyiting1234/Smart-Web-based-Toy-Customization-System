<template>
  <div class="row">
    <div class="col-2"></div>
    <div class="col-8">
      <div style="height: 35px"></div>
      <h1 style="font-family: 'swe'">Delivery way</h1>
      <div class="deliverCon">
        <ul class="list-group list-group-flush">
          <li class="list-group-item">
            <div class="cate">
              <div class="areaCate">
                <span class="area">In China</span>
                <div>
                  <span class="des"
                    >FLY TOY Members get free standard shipping (and discounted
                    expedited shipping) on every order. Otherwise, guestes are
                    required to pay ￥30 for each order<br />Just sign in during
                    checkout and you’ll automatically get free shipping.</span
                  >
                </div>
                <div style="height: 10px"></div>
                <router-link to="/signin"
                  ><button type="submit" class="btn btn-primary">
                    SIGN UP NOW
                  </button>
                </router-link>
                <div style="height: 10px"></div>
                <div>
                  <span style="font-size: 20px; font-weight: bold"
                    >Additional Information</span
                  >
                  <div class="des">
                    -We process and deliver orders Monday-Friday (excluding
                    holidays).
                    <br />
                    -We use a variety of shipping carries to make sure we
                    deliver your order as soon as possible.
                    <br />
                    -Customized toy will be produced in four weeks and arrived
                    around one weeks
                    <br />
                    -If you order more than one toys (excluding cutomized toys)
                    and send to the same address, the total fee of delivery will
                    be counted to once.
                  </div>
                </div>
              </div>
              <div style="height: 35px"></div>
              <div class="areaCate">
                <span class="area">In Other Countries</span>
                <div>
                  <span class="des"
                    >We are sorry to inform you that the brand is not currently
                    shipping overseas, but we believe that in the near future
                    the cute toys will be able to accompany you overseas!</span
                  >
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="col-2"></div>
  </div>
</template>
<style scoped>
.cate {
  display: flex;
  flex-direction: column;
  text-align: left;
  font-family: "nor";
}
.area {
  font-size: 35px;
  font-weight: bold;
}
.des {
  font-weight: bold;
}
</style>