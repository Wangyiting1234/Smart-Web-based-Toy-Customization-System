<template>
<div style="height:30px"></div>
  <div class="row">
    <div class="col-2"></div>
    <div class="col-8">
      <div class="empty">
        <div class="AddressEmptyImg">
          <img src="../../img/noAddress.png" />
        </div>
        <div class="AddressEmptyDis">
          <h1>YOUR ADDRESS IS EMPTY!</h1>
          <h5>DISPLAY YOUR Address AFTER LOGGING IN</h5>
          <div>
            <router-link to="/log">
              <button class="btn btn-primary">Log in</button>
            </router-link>
             <router-link to="/address/addaddress">
              <button class="btn btn-primary">Add new address</button>
            </router-link>
          </div>
        </div>
      </div>
    </div>
    <div class="col-2"></div>
  </div>
</template>
<style scoped>
.empty{
    display: flex;
}
img {
    width:400px;
    height: 400px;
    margin: 0 20px 0;
    }
.AddressEmptyDis{
    font-family: "nor";
    font-weight: "bold";
    padding-top: 10%;
}
button{
    margin:20px;
    width:150px;
}
</style>
