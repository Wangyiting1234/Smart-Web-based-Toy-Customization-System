<template>
 <div class="row">
    <h1 style="font-family: 'swe'; margin: 20px">ADD NEW ADDRESS</h1>
    <div class="col-2"></div>
    <div class="col-8">
      <van-address-edit
        :area-list="areaList"
   
        show-set-default
        :area-columns-placeholder="['Choose', 'Choose', 'Choose']"
        @save="onSave"
        :address-info="{
          name: info.name,
          tel: info.tel,
          addressDetail: info.addressDetail,
          postalCode: info.postalCode,
          isDefault: info.isDefault,
        }"
      />
    </div>
    <div class="col-2"></div>
  </div>
</template>
<script>
import { ref } from "vue";
import { showToast } from "vant";
import axios from "axios";
// import { areaList } from "@vant/area-data";
// import { areaList} from "@vant/area-data"
import { baseURL } from "../../public/urlConfig";
export default {
  data() {
    return {
      areaList: {
        province_list: {
          110000: "Beijing",
          330000: "Zhejiang Province",
        },
        city_list: {
          110100: "Beijing City",
          330100: "Hangzhou",
        },
        county_list: {
          110101: "Dongcheng District",
          110102: "Xicheng District",
          // ....
        },
      },
      info: [],
    };
  },
  methods: {
    onSave(content) {
      console.log(content);
      this.isDefault = content.isDefault ? "1" : "0";
      console.log(this.isDefault);
      var url =
        baseURL +
        "address/addaddress" +
        "?" +
        "receiverName=" +
        content.name +
        "&receiverPhone=" +
        content.tel +
        "&province=" +
        content.province +
        "&city=" +
        content.city +
        "&area=" +
        content.county +
        "&address=" +
        content.addressDetail +
        "&isDefault=" +
        this.isDefault +
        "&postCode=" +
        content.areaCode;
      console.log(content.name);
      axios
        .post(url, {
          receiverName: content.name,
          receiverPhone: content.tel,
          province: content.province,
          city: content.city,
          area: content.county,
          address: content.addressDetail,
          isDefault: this.isDefault,
          postCode: content.areaCode,
        })
        .then((res) => {
        if(res.data.state === 200){
            showToast("add new address successfully");
            this.$router.push("/address/deliveryaddress");
           }else if (res.data.state === 4001) {
            showToast(res.data.message);
          } else if (res.data.state === 5007) {
            showToast(res.data.message);
          } else if(res.data.state===5003) {
            this.$router.push("/log");
          }
        });
    },
  },
};
</script>