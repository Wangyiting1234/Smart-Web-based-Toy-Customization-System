<template>
  <div class="hot">
    <h1 style="text-align: left; font-family: 'swe'; margin: 20px">HOT TOYS</h1>
  </div>
  <!--end of selected bar-->
  <div style="height: 35px"></div>
  <div class="row">
    <div class="col-2"></div>
    <div class="col-8">
      <section>
        <ul>
          <li v-for="(item,index) in list" :key="index" @click="gotodetail(item.product_id)">
            <img  :src="require(`../assets/tony/${item.img}`)" alt="" />
            <h5 style="font-weight:bold">{{item.productName}}</h5>
            
            <h6>sales:{{item.sales}}</h6>
            <router-link style="font-size:20px" to="/productdetail">buy</router-link>
          </li>         
         
        </ul>
      </section>
    </div>

    <div class="col-2"></div>
  </div>
</template>
<style scoped>
.header ul {
  font-family: "nor";
  font-weight: bold;
  display: flex;
  align-items: center;
  justify-content: space-around;
  height: 50px;
  background-color: #b0c4de;
  color: #ffffff;
  top: 0px;
}
.icon {
  height: 20px;
  width: 20px;
}

.header ul li {
  display: flex;
  align-items: center;
}
.header ul li > div {
  padding: 0 5px;
}
.search-filter {
  display: flex;
  flex-direction: column;
}
.col-4:after {
  border: 1px soild slategray;
}
section {
  font-family: "nor";
}
section ul {
  display: flex;
  flex-wrap: wrap;
}
section ul li {
		margin: 15px;
		border: 2px solid #eee;
    border-radius: 15px;
    width: 30%;

}
section ul li img {
  width: 250px;
  height: 250px;
  margin:5%;
}
li:hover{
  background-color:lightgray;
}
section ul li h6{
  text-align:left;
  margin:5px;
  font-weight:bold;
}
</style>
<script>
import { ref } from "vue";
import { showToast } from "vant";
import axios from "axios";
import { baseURL } from "../../public/urlConfig";
export default{
  data(){
    return {
      list:[],
      toy:[],
    }
  },
  created(){
      var url = baseURL + "toy/hottoy";
      var self = this;
      axios.get(url).then((res) => {
        self.toy = res.data;
        if (res.data.state === 200) {
          this.list = self.toy.data;
          console.log(this.list)
          }
  })
  },
  methods:{
   gotodetail(index){
      this.$router.push({
          path:`/productdetail/${index}`,
      })
   }
  },
}
</script>