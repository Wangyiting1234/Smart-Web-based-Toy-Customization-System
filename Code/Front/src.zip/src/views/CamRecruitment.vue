<template>
  <div class="row">
      <div style="height:35px"></div>
       <h1 style="font-family: 'swe'">Campus Recruitment</h1>
    <div class="col-3">
      <!--the select bar of position starts-->
      <section>
        <div class="city">
          <span style="font-size: 25px; font-weight: bold">City</span>
          <van-radio-group v-model="checkedCity">
            <van-radio name="c1">Beijing</van-radio>
            <div class="space"></div>
            <van-radio name="c2">Shanghai</van-radio>
            <div class="space"></div>
            <van-radio name="c3">Guangzhou</van-radio>
            <div class="space"></div>
            <van-radio name="c4">Chengdu</van-radio>
          </van-radio-group>
        </div>
        <div class="position">
          <span style="font-size: 25px; font-weight: bold">Position</span>
          <van-radio-group v-model="checkedPos">
            <van-radio name="p1">Design</van-radio>
            <div class="space"></div>
            <van-radio name="p2">Technology</van-radio>
            <div class="space"></div>
            <van-radio name="p3">Marketing</van-radio>
            <div class="space"></div>
            <van-radio name="p4">Retail</van-radio>
            <div class="space"></div>
            <van-radio name="p5">Others</van-radio>
          </van-radio-group>
        </div>
      </section>
      <!--the select bar of position starts-->
    </div>
    <div class="col-7">
        <div style="height:30px"></div>
        <!--the list of seleced position-->
      <div class="posList">
        <ul>
          <li>
            <div class="posDetail">
              <h3 style="display:flex; margin-left: 5px;text-align-left">postition name</h3>
              <div class="selectRe"><span>city<span style="margin:3px">|</span></span><span>position cate</span>
              <div class="requireList">
                  <div><span style="margin:2px">-</span>reuqire list1</div>      
             </div>
              </div>
            </div>
            <div style="height:10px"></div>
          </li>
           <li>
            <div class="posDetail">
              <h3 style="display:flex; margin-left: 5px;text-align-left">postition name</h3>
              <div class="selectRe"><span>city<span style="margin:3px">|</span></span><span>position cate</span>
              <div class="requireList">
                  <div><span style="margin:2px">-</span>reuqire list1</div>      
             </div>
              </div>
            </div>
            <div style="height:10px"></div>
          </li>
           <li>
            <div class="posDetail">
              <h3 style="display:flex; margin-left: 5px;text-align-left">postition name</h3>
              <div class="selectRe"><span>city<span style="margin:3px">|</span></span><span>position cate</span>
              <div class="requireList">
                  <div><span style="margin:2px">-</span>reuqire list1</div>      
             </div>
              </div>
            </div>
            <div style="height:10px"></div>
          </li> <li>
            <div class="posDetail">
              <h3 style="display:flex; margin-left: 5px;text-align-left">postition name</h3>
              <div class="selectRe"><span>city<span style="margin:3px">|</span></span><span>position cate</span>
              <div class="requireList">
                  <div><span style="margin:2px">-</span>reuqire list1</div>      
             </div>
              </div>
            </div>
            <div style="height:10px"></div>
          </li> <li>
            <div class="posDetail">
              <h3 style="display:flex; margin-left: 5px;text-align-left">postition name</h3>
              <div class="selectRe"><span>city<span style="margin:3px">|</span></span><span>position cate</span>
              <div class="requireList">
                  <div><span style="margin:2px">-</span>reuqire list1</div>      
             </div>
              </div>
            </div>
            <div style="height:10px"></div>
          </li>
        </ul>
      </div>
    </div>
    <div class="col-2"></div>
  </div>
</template>
<style scoped>
section {
  margin: 10px;
  width: 80%;
  border: 2px solid rgb(196, 191, 191);
  border-radius: 10px;
}
section div {
  font-family: "nor";
  margin: 10px;
}
.selectRe{
    text-align:left;
    margin-left: 5px;

}
.posDetail{
    height:150px;
    font-family: 'nor';
    font-weight:20px;
      border: 2px solid rgb(196, 191, 191);
    border-radius: 10px;
    width:80%;
    display: flex;
    flex-direction: column;
}
.posDetail ul li{
    justify-content: center;
    align-items: center;
}
.space {
  height: 10px;
}
</style>
<script>
import { ref } from "vue";
export default {
  setup() {
    const checkedCity = ref("c1");
    const checkedPos = ref("p1");
    return { checkedCity, checkedPos };
  },
};
</script>