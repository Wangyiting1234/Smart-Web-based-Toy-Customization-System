<template>
    <router-view></router-view>
<div v-show="$route.meta.showFooter">
</div>
</template>