<template>
  <div class="signin">
    <div style="height: 40px"></div>
    <h1 style="font-family: swe">Log in</h1>
    <div class="row" style="margin: 20px; font-family: nor; font-weight: bold">
      <div class="col-3"></div>
      <div class="col-6">
        <van-form @submit="onSubmit">
          <van-cell-group inset>
            <van-field
              v-model="userTel"
              name="userTel"
              label="Telephone*"
              placeholder="please input your telephone number"
              :rules="telRules"
            />
            <van-field
              v-model="userPwd"
              type="password"
              name="userPwd"
              label="Password*"
              placeholder="please input your password"
              :rules="pwdRules"
            />
          </van-cell-group>
           <div>
            <router-link
              class="nav-link"
              style="color: #0d6efd; text-align: right"
              to="/signin"
              >has not registered?</router-link
            >
          </div>
          <div style="margin: 16px">
            <van-button round block type="primary" native-type="submit">
              Log in
            </van-button>
          </div>
        </van-form>
      </div>
      <div class="col-3"></div>
    </div>
  </div>
</template>
<script>
import { showToast } from "vant";
import axios from "axios";
import { baseURL } from "../../public/urlConfig";

export default {
  name: "login",
  data() {
    return {
      userTel: "", //user input
      userPwd: "",
      //rules of vertification
      telRules: [
        {
          requried: true,
          message: "telephone number can be not empty",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return /^(0|86|17951)?(13[0-9]|15[012356789]|166|17[3678]|18[0-9]|14[57])[0-9]{8}$/.test(
              value
            );
          },
          message: "please check the format of telephone number",
          trigger: "onBlur",
        },
      ],
      pwdRules: [
        {
          required: true,
          message: "password can be not empty",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return /^\w{6,12}$/.test(value);
          },
          message: "please check the format of password",
          trigger: "onBlur",
        },
      ],
    };
  },
  methods: {
    //click the button:login
    onSubmit(values) {
      // console.log("submit", values);
      var url =
        baseURL +
        "user/log" +
        "?" +
        "userTel=" +
        this.userTel +
        "&userPwd=" +
        this.userPwd;
      //var url = baseURL + "user/log";
      axios
        .post(url, {
          userTel: this.userTel,
          userPwd: this.userPwd,
        })
        .then((res) => {
          console.log(url);
          if (res.data.state === 200) {
          
      
            var userId = res.data.data.user_id;
            var userName = res.data.data.userName;
            console.log(userId);
            sessionStorage.setItem("userTel", this.userTel);
            sessionStorage.setItem("userPwd", this.userPwd);
            sessionStorage.setItem("userName",userName)
            // localStorage.setItem("token", this.msg);
            sessionStorage.setItem("userId",userId);
              let id = window.sessionStorage.getItem("Id");
            console.log(id);
            showToast("log in successfully");
            this.$router.push("/");
          } else if (res.data.state === 5001) {
            showToast(res.data.message);
          } else if (res.data.state === 5002) {
            showToast(res.data.message);
          }
        });
    },
  },
};
</script>