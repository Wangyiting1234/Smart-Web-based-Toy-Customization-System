<template>
  <div class="signin">
    <div style="height: 40px"></div>
    <h1 style="font-family: swe">Sign up</h1>
    <div class="row" style="margin: 20px; font-family: nor; font-weight: bold">
      <div class="col-3"></div>
      <div class="col-6">
        <van-form @submit="onSubmit">
          <van-cell-group inset>
            <van-field
              v-model="userTel"
              name="userTel"
              label="Telephone*"
              placeholder="please input your telephone number"
              :rules="telRules"
            />
            <van-field
              v-model="userPwd"
              type="password"
              name="userPwd"
              label="Password*"
              placeholder="please input your password"
              :rules="pwdRules"
            />
            <van-field
              v-model="userConPwd"
              type="password"
              name="userConPwd"
              label="Confirm Password*"
              placeholder="please input your password again"
              :rules="ConPwdRules"
            />
          </van-cell-group>
          <div>
            <router-link
              class="nav-link"
              style="color: #0d6efd; text-align: right"
              to="/Log"
              >already sign up?</router-link
            >
          </div>
          <div style="margin: 16px">
            <van-button round block type="primary" native-type="submit">
              Sign up
            </van-button>
          </div>
        </van-form>
      </div>
      <div class="col-3"></div>
    </div>
  </div>
</template>
<style scoped>
.col-sm-3 {
  text-align: left;
}
</style>
<script>
import { baseURL } from "../../public/urlConfig";
import { showToast } from "vant";
import axios from "axios";
export default {
  name: "singup",
  data() {
    return {
      userTel: "", //user input
      userPwd: "",
      userConPwd: "",
      //rules of vertification
      telRules: [
        {
          requried: true,
          message: "telephone number can be not empty",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return /^(0|86|17951)?(13[0-9]|15[012356789]|166|17[3678]|18[0-9]|14[57])[0-9]{8}$/.test(
              value
            );
          },
          message: "please check the format of telephone number",
          trigger: "onBlur",
        },
      ],
      pwdRules: [
        {
          required: true,
          message: "password can be not empty",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return /^\w{6,12}$/.test(value);
          },
          message: "please check the format of password",
          trigger: "onBlur",
        },
      ],
      ConPwdRules: [
        {
          required: true,
          message: "password can be not empty",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return /^\w{6,12}$/.test(value);
          },
          message: "please check the format of password",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return this.userPwd == value;
          },
          message: "confirm passwords are same",
          trigger: "onBlur",
        },
      ],
    };
  },
  methods: {
    onSubmit(values) {
      // console.log("submit", values);
      var url = baseURL + "user/signin"+"?"+"userTel=" +
         this.userTel +
        "&userPwd=" +
        this.userPwd;
      axios
        .get(url, {
          userTel: this.userTel,
          userPwd: this.userPwd,
        })
        .then((res) => {
          if (res.data.state === 200) {
            showToast("sign up successfully");
            this.$router.push("/log");
          } else if (res.data.state === 4000) {
            console.log("4000");
            showToast(res.data.message);
             this.$router.push("/singin");
          } else if (res.data.state === 5000) {
            showToast(res.data.message);
          } 
        });
    },
  },
};
</script>
