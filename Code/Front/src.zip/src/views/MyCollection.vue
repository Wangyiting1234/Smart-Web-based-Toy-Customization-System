<template>
    <h1 style="text-align: left; font-family: 'swe'; margin: 20px">MY COLLECTION</h1>
</template>