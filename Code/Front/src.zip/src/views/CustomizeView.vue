<template>
  <div class="about">
    <h1 style="font-family: 'swe'; margin: 20px">CUSTOMIZE YOUR BEAR</h1>
    <div class="customize">
      <div class="row">
        <div class="col-2">
          <van-tabs class="selected" v-model:active="activeName">
            <van-tab title="Cap" name="a">
              <div class="row">
                <div class="col-6" v-for="(item, index) in list" :key="index">
                  <van-button 
                  v-if="item.parentId==1"
                    type="primary"
                    class="button"
                    @click="changeList(item.customize_id);showGlassModel(index1[index])"
                    >{{item.customizeName}}</van-button
                  >
                </div>
              </div>
            </van-tab>
            <van-tab title="Hat" name="b">
              <div class="col-6" v-for="(item, index) in list" :key="index">
                <van-button
                 v-if="item.parentId==2"
                type="primary"
                class="button"
                @click="changeList(item.customize_id);showGlassModel(index2[index-13])"
                >{{item.customizeName}}</van-button
              >
           </div>
              
            </van-tab>
            <van-tab title="Hood" name="c">
              <div class="col-6" v-for="(item, index) in list" :key="index">
              <van-button
               v-if="item.parentId==3"
               
                type="primary"
                class="button"
                @click="changeList(item.customize_id);showGlassModel(index3[index-17])"
                >{{item.customizeName}}</van-button
              >
              </div>
              
        
            </van-tab>
            <van-tab title="Hair" name="d">
                <div class="col-6" v-for="(item, index) in list" :key="index">
              <van-button
              v-if="item.parentId==4"
                type="primary"
                class="button"
                @click="changeList(item.customize_id);showGlassModel(index4[index-20])"
                >{{item.customizeName}}</van-button
              >
              </div>
            </van-tab>
            <van-tab title="Glasses" name="e">
              <div class="row">

                <div class="col-6" v-for="(item, index) in list" :key="index">
                  <van-button
                   v-if="item.parentId==5"
                    type="primary"
                    class="button"
                    @click="changeList(item.customize_id);showGlassModel(index5[index-21])"
                    >{{item.customizeName}}</van-button
                  >
                 
                </div>
              </div>
            </van-tab>
          </van-tabs>
        </div>
        <div class="col-8">
          <div id="container"></div>
        </div>
        <div class="col-2">
          <div style="height:500px"></div>
          <div><router-link to="/customizeconfirm">  <input
                style="width: 150px; margin-top: 10px"
                class="btn btn-primary"
                type="submit"
                value="Confirm"
              /></router-link></diV>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import ModelView from "../utils/modelView";
import { ref } from "vue";
import { showToast } from "vant";
import axios from "axios";
import { baseURL } from "../../public/urlConfig";
export default {
  data() {
    return {
      modelView: null,
      acc: [],
      list: [],
      accList:[],
      index1: [],
      index2: [],
      index3: [],
      index4: [],
      index5: [],
    };
  },
  created() {
   
  },
  mounted() {
    this.initChart();
     this.loadAcc();
  },
  methods: {
    initChart() {
      this.modelView = new ModelView();
    },
    showGlassModel(name) {
      this.modelView.SetModelShow(name);
    },
    changeList(id){
        console.log(id)
        let ind = this.accList.indexOf(id);
        if(ind===-1){
          this.accList.push(id);
        }else{
          this.accList.splice(ind,1);
        }
        console.log(this.accList);
    },
    loadAcc() {
      var url = baseURL + "customize/acc";
      var self = this;
      axios.get(url).then((res) => {
        self.acc = res.data;
        if (res.data.state === 200) {
          this.list = self.acc.data;
           let a=0;
       let b=0;
       let c=0;
       let d=0;
   
          for (let i=0; i < self.acc.data.length; i++) {
            console.log(this.list[i].parentId);
            if (this.list[i].parentId == 1) {
              this.index1[i] = "Cap" + (i + 1);
             
            }
            else if (this.list[i].parentId == 2) {
              
             
              this.index2[a] = "Hat" + (a + 1);
              a++;
             
            }
            if (this.list[i].parentId == 3) {
                
              this.index3[b] = "Hood" + (b + 1);
              b++;
            }
            if (this.list[i].parentId == 4) {
             
              this.index4[c] = "Hair" + (c + 1);
           c++;
            }
            if (this.list[i].parentId == 5) {
              
              this.index5[d] = "Glasses" + (d + 1);
            d++;
            }
          }
  
          console.log(this.index5)
          
          
    
        }
      });
    },
  },
};
</script>



<style scoped>
.customize {
  width: 100%;
  height: 600px;
}
.model {
}
.selected {
  height: 500px;
}
.button {
  width: 100%;
  margin: 2px;
}
</style>