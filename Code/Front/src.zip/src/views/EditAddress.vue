<template>
     <div class="row">
    <h1 style="font-family: 'swe'; margin: 20px">EDIT ADDRESS</h1>
    <div class="col-2"></div>
    <div class="col-8">
      <van-address-edit
        :area-list="areaList"
        show-delete 
        show-set-default
        :area-columns-placeholder="['Choose', 'Choose', 'Choose']"
        @save="onSave"
        :address-info="{
          name: info.name,
          tel: info.tel,
          addressDetail: info.addressDetail,
          postalCode: info.postalCode,
          isDefault: info.isDefault,
        }"
      />
    </div>
    <div class="col-2"></div>
  </div>
</template>