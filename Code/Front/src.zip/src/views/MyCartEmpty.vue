<template>
  <div class="row">
    <div class="col-2"></div>
    <div class="col-8">
      <div class="empty">
        <div class="cartEmptyImg">
          <img src="../../img/EmptyCart.png" />
        </div>
        <div class="cartEmptyDis">
          <h1>YOUR CART IS EMPTY!</h1>
          <h5>DISPLAY YOUR TOYS AFTER LOGGING IN</h5>
          <div>
            <router-link to="/log">
              <button class="btn btn-primary">Log in</button>
            </router-link>
            <router-link to="/">
              <button class="btn btn-primary">Shopping</button>
            </router-link>
          </div>
        </div>
      </div>
    </div>
    <div class="col-2"></div>
  </div>
</template>
<style scoped>
.empty{
    display: flex;
}
.cartEmptyImg {
    width:60%;
  
}
.cartEmptyDis{
    font-family: "nor";
    font-weight: "bold";
    padding-top: 10%;
}
button{
    margin:20px;
    width:100px;
}
</style>
