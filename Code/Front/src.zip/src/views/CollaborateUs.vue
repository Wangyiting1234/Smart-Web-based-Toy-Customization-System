<template>
  <div class="row">
    <div class="col-2"></div>
    <div class="col-8">
      <div style="height: 35px"></div>
      <h1 style="font-family: 'swe'">Collaborate Us</h1>
      <div class="coCate">
        <ul class="list-group list-group-flush">
          <li class="list-group-item">
            <div class="brand">
              <span class="coWay">BRAND LICENSING</span>
              <div>
                <span class="des"
                  >-Brand Resource:Fly Toy supports unique online customized
                  plush bears, which can create unique co-branded products based
                  on brand image and strong alliance with the brand</span
                >
              </div>
              <div style="height: 10px"></div>
              <div>
                <span>COOPERTAION CONTACT</span>
                <div class="linkename">
                  <span>Cooperation linkman</span><span>:</span
                  ><span>Elsa</span>
                </div>
                <div class="contactEmail">
                  <span>Email address</span><span>:</span
                  ><span>wang.yiting@student.zy.cdut.edu</span>
                </div>
                <div class="address">
                  <span>Address</span><span>:</span
                  ><span
                    >Section 2, Chenghua Avenue, Chenghua District, Chengdu,
                    Sichuan Province, China</span
                  >
                </div>
              </div>
              <div></div>
            </div>
          </li>
          <li class="list-group-item">
            <div class="brand">
              <span class="coWay">COOPERTAION</span>
              <div>
                <span class="des"
                  >-Offline Store: the brand has wireless stores all
                  over the world at present, if you want to carry out offline stores in
                  shopping malls, airports, subways, office buildings and other
                  areas around the world, please contact us</span
                >
              </div>
              <div style="height: 10px"></div>
              <div>
                <span>COOPERTAION CONTACT</span>
                <div class="linkename">
                  <span>Cooperation linkman</span><span>:</span
                  ><span>Elsa</span>
                </div>
                <div class="contactEmail">
                  <span>Email address</span><span>:</span
                  ><span>wang.yiting@student.zy.cdut.edu</span>
                </div>
                <div class="address">
                  <span>Address</span><span>:</span
                  ><span
                    >Section 2, Chenghua Avenue, Chenghua District, Chengdu,
                    Sichuan Province, China</span
                  >
                </div>
              </div>
              <div></div>
            </div>
          </li>
         
        </ul>
      </div>
    </div>
    <div class="col-2"></div>
  </div>
</template>
<style scoped>
.brand {
  display: flex;
  flex-direction: column;
  text-align: left;
  font-family: "nor";
}
.coWay {
  font-size: 35px;
  font-weight: bold;
  text-align: left;
}
.des {
  color: slategray;
  font-weight: bold;
}
</style>