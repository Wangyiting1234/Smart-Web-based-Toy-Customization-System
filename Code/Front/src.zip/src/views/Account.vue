<template>
<router-view></router-view>
<div v-show="$route.meta.showFooter">
 <h1 style="font-family: 'swe'; margin: 20px">MY ACCOUNT</h1>
 <div class="row">
   <div class="col-3">
     <sideBar></sideBar>
   </div>
   <div class="col-7">
      <div class="showInfo">
          <img src="../../img/robot.png" style="width:200px;padding:15px">

          <div class="userInfo">
            <div class="userTel" style="font-size:25px">{{userTel}}</div>
            <div class="userName">{{userName}}</div>
            
          
            <router-link to="/user/modifyuserinfo">Modify personal information>></router-link>
            </div>
        
          <div></div>
      </div>
      <div class="comFun">
        <div class="row">
        <div class="col-6 unreceived">
          <img src="../../img/tran.png" style="width:40%;height:90%">
          <div class="funDe">
            <span style="font-size:25px">Unreceived Orders</span>
            <div><router-link to="/user/unrecievedorder">check unreceived orders>></router-link></div>
          </div>
          
          
          </div>
          <div class="col-6 collection">
          <img src="../../img/collectionImg.png" style="width:40%;height:90%">
          <div class="funDe">
             <span style="font-size:25px">My Collection</span>
            <div><router-link to="/user/mycollection">check my collection>></router-link></div>
          </div>
          </div>
          </div>
      </div>
     
     </div>
      <div style="height:20px"></div>
   <div class="col-2"></div>
 </div>
  
 </div>
</template>
<script>
import sideBar from "@/components/SideBar";
import { baseURL } from "../../public/urlConfig";
export default{
  components:{sideBar},
  data(){
    return{
      useraname:"",
      userTel:"",
   
  
    }
  },
   created(){
     if(!window.sessionStorage.getItem("userId")){
          this.$router.push({path:'/log'})
      }
      if(window.sessionStorage.getItem("userName")){
        this.userName = "[Username Not Set]";
      }
      this.userTel = window.sessionStorage.getItem("userTel");
     
  },
  //   data:{
//     userTel:"",
//   },
//   created(){
//     this.getUserTel()
//   },
//   methods:{
//     getUserTel(){
//       var url = baseURL+'user/log'
//       axios.get(url)
//       .then(res=>{
//         this.userTel = res.data
//       })
//     }
//   }
// }
}
</script>
<style scoped>
.userInfo{
  padding:50px;

  font-weight: bold;
  text-align:left;
}
.showInfo{
  background-color: #b0c4de;
  height:220px;
  margin-bottom: 20px;
  display:flex;
}
.comFun{
  background-color: #b0c4de;
  height:220px;
  display:flex;
}
.unreceived{
  padding:35px;
  display: flex;
}
.collection{
  padding:35px;
  display: flex;
}
.funDe{
  /* padding: 30px; */
  padding-top:35px;
  padding-left:10px
}

.row{
    font-family: 'nor';
    font-weight: bold;
}
span{
  flex-direction:row;
}
a{
  color: #111111;
}
a:hover{
  color: whitesmoke;
}
</style>
