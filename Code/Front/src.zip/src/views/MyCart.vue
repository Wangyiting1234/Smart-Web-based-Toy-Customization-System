<template>
  <div>
    <h1 style="font-family: 'swe'; margin: 10px">My Toys</h1>
    <div>
      <div class="row">
        <div class="col-2"></div>
        <div class="col-8">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>
                  <!-- <input
                    class="form-check-input"
                    type="checkbox"
                    value=""
                    id="flexCheckDefault"
                    style="margin-right: 5px"
                  />Select all -->
                </th>
                <th scope="col">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    fill="currentColor"
                    class="bi bi-bag"
                    viewBox="0 0 16 16"
                  >
                    <path
                      d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5zM2 5h12v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5z"
                    />
                  </svg>
                </th>
                <th scope="col">Quantity</th>
                <th scope="col">Toy price</th>
                <th scope="col">Total</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody style="" >
              <tr v-for="(item, index) in list" :key="index">
            
                <td scope="row" >
                      <!-- <input
                    v-model="check"
                    style="align: center"
                    class="form-check-input"
                    type="checkbox"
                    value="product.id"
                    id="flexCheckDefault"
                    @click.stop="checkChoose()"
                 
                  /> -->
                  <input
                    v-model=picked[item.productId]
                    style="align: center"
                    class="form-check-input"
                    type="checkbox"
                    value=""
                    id="flexCheckDefault"
                    @click="updateInfo()"
                  />{{picked}}
                
                </td>
                <td>
           
                  <div >
                   {{item.productName}}
                  </div>
                </td>
                <td class="quantity">
                 <div>{{value[index]}}</div> 
                </td>
                <td class="price" ><div >{{item.productPrice}}</div></td>
                <td class="eachTotal"><div >{{Total[index]}}</div></td>
                <td><div><button class="btn btn-primary" >delete</button></div></td>
              </tr>
              
            </tbody>
          </table>
          <footer>
            <div></div>
            <div>
              <div>
                <span style="font-size: 20px">{{toytotal}}</span> toys in total
              </div>
              <div>
                Order total: <span style="font-size: 20px">{{pricetotal}}</span>
              </div>
            </div>
            <div>
              <input
                style="width: 150px; margin-top: 10px"
                class="btn btn-primary"
                type="submit"
                value="Buy"
                
              />
            </div>
          </footer>
        </div>
        <div class="col-2"></div>
      </div>
    </div>
  </div>
</template>
<style scoped>
.table {
  font-family: "nor";
}
footer {
  text-align: right;
  margin: 20px;
  font-family: "nor";
  font-weight: bold;
}
tbody tr td{
  font-weight: bold;
  
  
}

</style>
<script>
import axios from "axios";
import { baseURL } from "../../public/urlConfig";
export default{
  data(){
    return{
      check:[],
      picked:{},
      selected:[],
      cart:[],
      list:[],
      Total:[],
      value:[],
      toytotal:"",
      pricetotal:"",
    }
    
    
  },
  created(){
   this.loadCart();
  },

  methods:{
    loadCart(){
      var url = baseURL + "cart/cartlist";
      var self = this;
      axios.get(url).then((res) => {
        self.cart = res.data;
        this.toytotal = 0;
        this.pricetotal = 0;
        if (res.data.state === 200) {
          this.list = self.cart.data;
          if (self.cart.data.length == 0) {
            this.$router.push("/mycartempty");
          }
          for (let i = 0; i < self.cart.data.length; i++) {
            this.Total[i] = this.list[i].productNum*this.list[i].productPrice;
            this.value[i] = this.list[i].productNum;
            // this.toytotal = this.list[i].productNum+this.toytotal;
            // this.pricetotal +=this.Total[i];
          }
          
          console.log(this.Total);
        }
      });
    },
    updateInfo(id){
      console.log(this.picked);

      console.log(id);
      for(let key in this.picked){
        console.log("key"+key);
        if(this.picked[key]==true&&this.selected.indexOf(key)){   
            this.selected.push(key);
        }
        if(this.picked[key]==false&&this.selected.indexOf(key)){
          for(let i =0;i<this.selected.length;i++){
            if(this.selected[i]==key){
              this.selected.splice(i,1)
            }
          }
        }

        
     
      }
      console.log("select"+this.selected)
      // Object.keys(this.picked).forEach(key=>{
      //   console.log(key,this.picked[key])
      // })
    }
  }
}
</script>




