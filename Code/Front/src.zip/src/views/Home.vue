<template>
  <!-- start to show the slide of homepage-->
  <div
    id="carouselExampleControls"
    class="carousel slide"
    data-bs-ride="carousel"
  >
    <div class="carousel-inner">
      <div class="carousel-item active" >
        <img
          src="../../img/showslide1.jpg"
          class="d-block w-100"
          alt=""
          style="width: 100%; height: 550px"
        />
      </div>
      <div class="carousel-item" >
        <img
          src="../../img/showslide2.jpg"
          class="d-block w-100"
          alt=""
          style="width: 100%; height: 550px"
        />
      </div>
      <div class="carousel-item" >
        <img
          src="../../img/showslide3.jpg"
          class="d-block w-100"
          alt=""
          style="width: 100%; height: 550px"
        />
      </div>
     
    </div>
  </div>
  <!-- end to show the slide of homepage-->
  <!-- start to show customize intro-->
  <div class="customize">
    <div class="row" style="height: 500px">
      
      <div class="col" style="background-color: #dcdcdc">
        <div style="height: 40%"></div>
        <span><h2 style="font-family: 'swe'">CUSOMTIZE BEARS</h2></span>
        <div>
          <h5 style="font-family: 'nor'">
            Do you want to own your exculsive bear?<br />Your toys Designed by
            you
          </h5>
        </div>
          <router-link to="/customize">
        <button
          type="button"
          class="btn btn-secondary btn-lg"
          style="width: 150px; font-family: 'nor'; margin: 10px"
        >
          Design
        </button>
          </router-link>
      </div>
      <div class="col"><img src="../../img/cus.png"/></div>
    </div>
    <div style="height: 40px"></div>
  </div>
  <!-- end to show the slide of homepage-->
  <!-- start to show the newest toys-->
  <div style="height: 350px">
    <span
      ><h2 style="font-family: 'swe'; text-align: left">NEWEST TOYS</h2></span
    >
    <div class="row">
      <div
        v-for="(item, index) in list"
        :key="index"
        @click="gotodetail(item.id)"
        class="col-3 newouter"
        style="
          display: flex;
          flex-direction: coloum;
          justify-content: center;
          align-items: center;
        "
      >
        <div class="newInner">
          <img 
            v-if="item.img"
            style="width: 100%"
            :src="require(`../assets/tony/${item.img}`)"
            class="rounded float-start"
            alt="..."
          />
        </div>
      </div>
      <div
        v-for="(item, index) in list"
        :key="index"
        class="col-3 newouter"
        style="
          display: flex;
          flex-direction: coloum;
          justify-content: center;
          align-items: center;
        "
      >
        <span
          style="
            font-family: 'nor';
            font-size: 20px;
            font-weight: bolder;
            text-align: center;
          "
          >{{ item.productName }}</span
        >
      </div>
    </div>
  </div>
  <div style="height: 40px"></div>
  <!-- end to show the newest toys-->
  <!-- start to show customize guide-->
  <div class="customizeGuide">
    <div class="row" style="height: 500px">
      <div class="col"><img src="../../img/guide.png"/></div>
      <div class="col" style="background-color: #dcdcdc">
        <div style="height: 40%"></div>
        <span><h2 style="font-family: 'swe'">CUSTOMIZED GUIDE</h2></span>
        <div>
          <h5 style="font-family: 'nor'">
            Do you know how to design a stunning bear by yourself?<br />Before
            your design, the tips and samples may be give you inspiration
          </h5>
        </div>
        <router-link to="/customizeguide">
          <button
            type="button"
            class="btn btn-secondary btn-lg"
            style="width: 150px; font-family: 'nor'; margin: 10px"
          >
            Explore
          </button>
        </router-link>
      </div>
    </div>
  </div>
  <!-- start to show customize guide-->
</template>
<style scoped>
.newInner:hover {
  background-color: lightgray;
}
</style>
<script>
// @ is an alias to /src
import Navbar from "@/components/Navbar";
import MainBar from "@/components/MainBar";
import axios from "axios";
import { ref } from "vue";
import { showToast } from "vant";
import { baseURL } from "../../public/urlConfig";
export default {
  name: "HomeView",
  data() {
    return {
      toy: [],
      list: [],

    };
  },
  components: {
    Navbar,
    MainBar,
  },
  created() {
    this.loadNewToy(),
      axios({
        url: "/",
      }).then((res) => {
        console.log(res);
      });
  },
  methods: {
    loadNewToy() {
      var url = baseURL + "toy/newtoy";
      var self = this;
      axios.get(url).then((res) => {
        self.toy = res.data;
        if (res.data.state === 200) {
          this.list = self.toy.data;
          console.log(this.list);
        }
      });
    },
  },
};
</script>

