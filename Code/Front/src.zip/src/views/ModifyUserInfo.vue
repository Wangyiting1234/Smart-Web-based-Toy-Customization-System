<template>
  <div style="height: 40px"></div>
  <h1 style="font-family: swe">Modify Your Information</h1>
  <div class="row" style="margin: 20px; font-family: nor; font-weight: bold">
    <div class="col-3"></div>
    <div class="col-6">
      <div style="height: 30px"></div>
      <van-form @submit="onSubmit">
        <van-cell-group inset>
          <van-field
            v-model="userName"
            name="userName"
            label="Username"
            placeholder="please input your username"
            :rules="usernameRules"
          />
          <div class="form-sex">
            <label>Gender：</label>
            <label class="radio-inline sex">
              <input
                type="radio"
                name="sex"
                id="male"
                value="1"
                v-model="userGender"
              />
              male
            </label>
            <label class="radio-inline">
              <input
                type="radio"
                name="sex"
                id="female"
                value="0"
                v-model="userGender"
              
              />
              female
            </label>
          </div>
        </van-cell-group>
        <div style="margin: 16px">
          <van-button round block type="primary" native-type="submit">
            Confirm
          </van-button>
        </div>
      </van-form>
    </div>
    <div class="col-3"></div>
  </div>
</template>
<script>
import { baseURL } from "../../public/urlConfig";
import { showToast } from "vant";
import axios from "axios";
export default {
  name: "modifyInfo",
  data() {
    return {
      userName: "",
      userGender: "",
      userGenderRules:[
        {
          required:true,
          message:"gender can be not unselected",
          trigger:"onBlur",
        } 
      ],
      usernameRules: [
        {
          required: true,
          message: "user name can be not empty",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return /^[a-zA-Z]{1}/.test(value);
          },
          message: "User name must start with a letter",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            const str = value.trim();
            const len = str.length;
            return !(len < 3 || len > 10);
          },
          message: "The length of the username is 3 to 10 characters",
          trigger: "onBlur",
        },
        {
          validator: (value) => {
            return /^[a-zA-Z0-9\_)]{3,10}$/.test(value);
          },
          message:
            "Username can contain only letters, numbers, and underscores",
          trigger: "onBlur",
        },
      ],
    };
  },
  methods: {
    onSubmit(values) {
      var url =
        baseURL +
        "user/modifyuserinfo" +
        "?" +
        "userName=" +
        this.userName +
        "&userGender=" +
        this.userGender;
      axios
        .post(url, {
          userName: this.userName,
          userGender: this.userGender,
        })
        .then((res) => {
          if (res.data.state === 200) {
            showToast("Modify successfully");
            this.$router.push("/");
          } else if (res.data.state === 5006) {
            showToast(res.data.message);
          }
        });
    },
  },
};
</script>
<style scoped>
.form-sex {
  text-align: left;
  margin-top: 10px;
  margin-left: 15px;
}
.sex {
  padding: 5px;
}
</style>