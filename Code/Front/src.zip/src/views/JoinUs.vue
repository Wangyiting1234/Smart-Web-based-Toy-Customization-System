<template>
  <div>
    <div class="row">
      <div class="col-2"></div>
      <div class="col-8">
        <div style="height: 35px"></div>
        <h1 style="font-family: 'swe'">JOIN US</h1>
        <div style="height: 35px"></div>
        <div class="joinContent">
          <h4>
            Fly Toy is an online sales platform with bold ideas and wild ideas.
            We welcome friends who jump thinking, welcome friends who have
            unique insights into the toy industry, welcome friends who work
            seriously and patiently, welcome friends who have a strong basic
            understanding of the position, if you love this brand and want to
            innovate and improve this brand together,welcome to join us.
          </h4>
        </div>

        <div class="recruitment">
          <div class="experienced">
            <router-link to="/exrecruitment">
              <img src="../../img/worker.png" />
              Experienced Recruitment
            </router-link>
          </div>
          <div class="campus">
            <router-link to="/camrecruitment">
              <img src="../../img/student.png" />
              Campus Recruitment
            </router-link>
          </div>
        </div>
      </div>

      <div class="col-2"></div>
    </div>
  </div>
</template>
<style scoped>
h4 {
  font-family: "nor";
  text-align: left;
  line-height: 30px;
}
.recruitment {
  display: flex;
  justify-content: space-between;
  height: 250px;
  background-color: #fff;
}
.experienced {
  background-color: #739fd8;
  margin: 45px;
  width: 40%;
  height: 60%;
  border-radius: 10px;
  font-family: "nor";
  font-size: 20px;
  font-weight: bolder;
}
.experienced:hover {
  background-color: #b0c4de;
}
.campus {
  background-color: #739fd8;
  margin: 45px;
  width: 40%;
  height: 60%;
  border-radius: 10px;
  font-family: "nor";
  font-size: 20px;
  font-weight: bolder;
}
.campus:hover {
  background-color: #b0c4de;
}
img {
  width: 100px;
  margin: 20px;
}
a {
  color: #000;
}
</style>