<template>
  <div>
    <div class="row">
      <div class="col-2"></div>
      <div class="col-8">
        <div style="height: 35px"></div>
        <h1 style="font-family: 'swe'">INTRODUCTION</h1>
        <div style="height: 35px"></div>
        <div>
       <h4> FLY TOY is an online platform for the sale of plush toys. It is also a
        platform for people who may want to have a unique plush bear of their
        own design, for people who want to give a unique gift to someone they
        love or a loved one or a friend, or for people who want to give their
        children or loved ones a plush bear to replace the one you have with
        them.<br> The FLY TOY name is the creator of the brand. We hope that no
        matter what hardships you are going through, no matter what difficulties
        you are experiencing, you will not get stuck in your own mind or even in
        yourself.<br> We are constantly trying to come up with cuter, quirkier and
        more unique designs to make your customised bear perfect. We are also
        constantly maintaining the site, trying to publish a more comfortable
        and smooth interactive experience.<br> Let yourself go, there's always a
        warm toy waiting for you! 
        </h4>
      </div>
      </div>
      
      
      <div class="col-2"></div>
    </div>
  </div>
</template>
<style scoped>
h4{
  font-family: 'nor';
  text-align: left;
  line-height: 40px;
}
</style>