<template>
  <div class="about">
    <div class="row">
      <div class="col-2"></div>
      <div class="col-8">
        <div class="row">
          <div style="height:35px"></div>
          <h3 style="text-align: left;margin-bottom:20px">Frequently Asked Question</h3>
          <div class="col-4">
            <div class="list-group" id="list-tab1" role="tablist">
              <div style="text-align:left;background-color:#739fd8"><h5 style="color:#f0f0f0;margin:3%">About Customized toys</h5></div>
              <a
                class="list-group-item list-group-item-action active"
                id="list-slip-list1"
                data-bs-toggle="list"
                href="#list-slip"
                role="tab"
                aria-controls="slip"
                >Please when will it be shipped?</a
              >
              <a
                class="list-group-item list-group-item-action"
                id="list-place-list1"
                data-bs-toggle="list"
                href="#list-amend"
                role="tab"
                aria-controls="amend"
                >Can I amend my order for customized toys?</a
              >
              <a
                class="list-group-item list-group-item-action"
                id="list-change-list1"
                data-bs-toggle="list"
                href="#list-exchange"
                role="tab"
                aria-controls="exchange"
                >Can I exchange my order?</a
              >
              <a
                class="list-group-item list-group-item-action"
                id="list-difference-list1"
                data-bs-toggle="list"
                href="#list-difference"
                role="tab"
                aria-controls="difference"
                >Can I return the color difference between the product and the picture?</a
              >
            </div>
          </div>
          <div class="col-8">
            <div class="tab-content" id="nav-tabContent1">
              <div
                class="tab-pane fade show active"
                id="list-slip"
                role="tabpanel"
                aria-labelledby="list-slip-list"
              >
              Customized products will generally be delivered to you in about 4-6 weeks, in case of holidays or other special circumstances, the generation cycle will be adjusted accordingly, please pay attention to the official website for details Notice or check the order status.
              </div>
              <div
                class="tab-pane fade"
                id="list-amend"
                role="tabpanel"
                aria-labelledby="list-amend-list"
              >
               Once a custom toy order is generated, the system cannot modify it. If the product has not started production, it can be refunded and remade, if the production has started, the product cannot be modified and returned.
              </div>
              <div
                class="tab-pane fade"
                id="list-exchange"
                role="tabpanel"
                aria-labelledby="list-exchange-list"
              >
               Since custom toys are custom-made, we do not accept any returns and exchanges except for quality problems, and it is recommended to customize carefully.
              </div>
              <div
                class="tab-pane fade"
                id="list-difference"
                role="tabpanel"
                aria-labelledby="list-difference-list"
              >
               Due to the different resolution of the display, the color difference between the real object and the picture is normal, not a quality problem, so it cannot be returned.
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div style="height:35px"></div>
          <div class="col-4">
            <div class="list-group" id="list-tab2" role="tablist">
              <div style="text-align:left;background-color:#739fd8"><h5 style="color:#f0f0f0;margin:3%">About mass-produced toys</h5></div>
              <a
                class="list-group-item list-group-item-action active"
                id="list-slip2-list2"
                data-bs-toggle="list"
                href="#list-slip2"
                role="tab"
                aria-controls="slip2"
                >Please when will it be shipped?</a
              >
              <a
                class="list-group-item list-group-item-action"
                id="list-place-list2"
                data-bs-toggle="list"
                href="#list-place2"
                role="tab"
                aria-controls="place"
                >Can I cancel my order after I place it?</a
              >
              <a
                class="list-group-item list-group-item-action"
                id="list-change-list2"
                data-bs-toggle="list"
                href="#list-change"
                role="tab"
                aria-controls="change"
                >What should I do if the information is filled in incorrectly when placing an order?</a
              >
              <a
                class="list-group-item list-group-item-action"
                id="list-difference-list2"
                data-bs-toggle="list"
                href="#list-difference"
                role="tab"
                aria-controls="difference"
                >Can I return the color difference between the product and the picture?</a
              >
            </div>
          </div>
          <div class="col-8">
            <div class="tab-content" id="nav-tabContent2">
              <div
                class="tab-pane fade show active"
                id="list-slip2"
                role="tabpanel"
                aria-labelledby="list-slip2-list2"
              >
              Mass-produced products will generally be delivered to you in about 1 week, in case of holidays or other special circumstances, the generation cycle will be adjusted accordingly, please pay attention to the official website notice or check the order status for details.
              </div>
              <div
                class="tab-pane fade"
                id="list-place2"
                role="tabpanel"
                aria-labelledby="list-place-list2"
              >
               If the order is placed, it cannot be cancelled. If the order is not shipped, you can click Request Refund to return it. The status of your order can be found in "My Orders".
              </div>
              <div
                class="tab-pane fade"
                id="list-change"
                role="tabpanel"
                aria-labelledby="list-change-list2"
              >
               Please contact customer service in time to verify the processing.
              </div>
              <div
                class="tab-pane fade"
                id="list-difference"
                role="tabpanel"
                aria-labelledby="list-difference-list2"
              >
               Due to the different resolution of the display, the color difference between the real object and the picture is normal, not a quality problem, so it cannot be returned.
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div style="height:35px"></div>
          <div class="col-4">
            <div class="list-group" id="list-tab3" role="tablist">
              <div style="text-align:left;background-color:#739fd8"><h5 style="color:#f0f0f0;margin:3%">After-sales service</h5></div>
              <a
                class="list-group-item list-group-item-action active"
                id="list-return-list3"
                data-bs-toggle="list"
                href="#list-return"
                role="tab"
                aria-controls="return"
                >No reason to return time</a
              >
              <a
                class="list-group-item list-group-item-action"
                id="list-place-list3"
                data-bs-toggle="list"
                href="#list-quality"
                role="tab"
                aria-controls="quality"
                >Quality problem return and exchange</a
              >
            </div>
          </div>
          <div class="col-8">
            <div class="tab-content" id="nav-tabContent3">
              <div
                class="tab-pane fade show active"
                id="list-return"
                role="tabpanel"
                aria-labelledby="list-return-list3"
              >
              Support 15 days no reason to return or exchange. Within 15 days of receiving the goods, there are no traces of use, the hang tags are complete, and the goods will be returned and exchanged without affecting 2 sales, please contact our online customer service in time to help you deal with it.
              </div>
              <div
                class="tab-pane fade"
                id="list-quality"
                role="tabpanel"
                aria-labelledby="list-quality-list3"
              >
              If there is a quality problem, contact the online customer service in time, provide a clear picture of the quality problem, and the customer service will comply with the national three-guarantee policy and will deal with it properly for you.
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-2"></div>
      <div style="height:35px"></div>
    </div>
  </div>
</template>
<style scoped>
.tab-pane{
  text-align:left;
}
.row{
  font-family:'nor';
  font-weight:bold;
}
</style>
