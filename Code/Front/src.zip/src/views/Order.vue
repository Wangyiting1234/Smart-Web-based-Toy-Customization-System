<template>
  <div class="row">
    <h1 style="text-align: left; font-family: 'swe'; margin: 20px">
      Confirm Your Order
    </h1>

    <div class="col-2"></div>
    <div class="col-8 info">
      <div class="address">
        <div><p>Select Delivery Address:</p></div>
        <select>
          <option v-for="(item, index) in list" :key="index">{{ item.receiverName }} {{ item.address }} {{ item.receiverPhone }} </option>
        </select>
      </div>
      <div class="order">
         <div class="title"> <p>Order List:</p></div>
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  class="bi bi-bag"
                  viewBox="0 0 16 16"
                >
                  <path
                    d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5zM2 5h12v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5z"
                  />
                </svg>
              </th>
              <th scope="col">Quantity</th>
              <th scope="col">Toy price</th>
              <th scope="col">Total</th>
            
            </tr>
          </thead>
          <tbody style="">
            <tr>
              <td>
                <div v-for="(key, value) in obj" :key="key">
                  <span v-if="value=='productName'" >{{ key}}</span>
                </div>
              </td>
              <td class="quantity">
                <diV v-for="(key, value) in obj" :key="key">
                  <span v-if="value=='productNum'" >{{ key}}</span>
                </div>
               
              </td>
              <td class="price" >
                <div  v-for="(key, value) in obj" :key="key"> <span v-if="value=='productPrice'" >{{ key}}</span></div>
              </td>
              <td class="eachTotal">
                <div>{{total}}</div>
              </td>
            </tr>
          </tbody>
        </table>
             <footer>
            <div></div>
            <div>
              <input
                style="width: 150px; margin-top: 10px"
                class="btn btn-primary"
                type="submit"
                value="Pay"
              />
            </div>
          </footer>
      </div>
    </div>
    <div class="col-2"></div>
    <div style="height:20px"></div>
  </div>
</template>
<style>
.col-8 .info {
    display: flex;
    font-weight: bolder;
    font-family: "nor";
    
}

.address {
    display: flex;
    flex-direction: column;
  float: left;
  width: 100%;
}
select {
     
  width: 100%;
  height: 50px;
  border-radius: 5px;
  border: 2px solid;
}
p {
    font-size:25px;
    margin:5px;
  text-align: left;
  font-family: "nor";
  font-weight:bold;
}
.title{
    width:100%;
    height:30px;
 
}
.order {
    border: 2px solid;
    border-radius: 5px;
    margin-top:20%;

}
.table {
  font-family: "nor";
}
footer {
  text-align: right;
  margin: 20px;
  font-family: "nor";
  font-weight: bold;
}
</style>
<script>
import { ref } from "vue";
import { showToast } from "vant";
import axios from "axios";
import { baseURL } from "../../public/urlConfig";
export default {
  data() {
    return {
      list:[],
      address:[],
      total:"",
      obj:{}
    };
  },
  created() {
    if (!window.sessionStorage.getItem("userId")) {
      this.$router.push("/log");
    }
    this.loadAddress();
    this.loadInfo();
  },
  methods:{
        loadAddress() {
      var url = baseURL + "address/deliveryaddress";
      var self = this;
      axios.get(url).then((res) => {
        self.address = res.data;

        if (res.data.state === 200) {
          this.list = self.address.data;
          console.log(this.list)
          // for (let i = 0; i < self.address.data.length; i++) {
          //   this.list[i].id = i + 1;
          // }
        }
      });
    },
    loadInfo(){
   
    let url = window.location.href;
    let info = url.split('?')[1];
    console.log(info)
    let getInfo = info.split('&');
    let price=0;
    let quantity=0;
    for(let i=0;i<getInfo.length;i++){
      let item  = getInfo[i].split('=')
      let key = item[0]
      let value = item[1]
      if(key=='productName'){
        if(value.includes("+")){value=value.replace("+","\0")}
      }
      if(key=='productNum'){
          quantity  = value;
      }
      if(key=='productPrice'){
        price= value;
      }
    
      this.obj[key] = value;
      console.log(this.obj)
    }
      this.total = quantity*price;

    }
  }
};
</script>